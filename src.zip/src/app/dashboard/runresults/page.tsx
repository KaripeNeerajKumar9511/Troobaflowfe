"use client";

import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { ArrowUp, ArrowDown, ArrowUpDown, Lock } from 'lucide-react';
import { useSortableTable, type SortDir } from '@/hooks/useSortableTable';
import { useModelStore, type Model } from '@/stores/modelStore';
import { useScenarioStore } from '@/stores/scenarioStore';
import { useResultsStore } from '@/stores/resultsStore';
import { PRODUCT_METRIC_LABELS } from '@/lib/productMetricLabels';
import { type CalcResults, type ProductResult, type EquipmentResult, type LaborResult, calculate, isUtilOnlyCalcResults } from '@/lib/calculationEngine';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../../components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '../../../components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../../components/ui/Select';
import { Input } from '../../../components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/Checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tooltip as ShadTooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import {
  Play, CheckCircle, AlertTriangle, Shield, XCircle, RotateCcw, Network, Gauge, RefreshCw, Clock,
  TrendingUp, BarChart3, Settings2, Square, ChevronRight, ToggleLeft, Layers,
} from 'lucide-react';
import IBOMOutput, { MCT_COLORS, TreeChart, TreeTable, PolesChart, PolesTable, MCTLegend, buildNodeTree, buildPoles } from '@/components/IBOMOutput';
import { toast } from 'sonner';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend,
  ResponsiveContainer, ReferenceLine,
} from 'recharts';
import { useRunCalculation, type RunMode } from '@/hooks/useRunCalculation';
import { useRunIssueBannerDismiss, type RunIssueDismissPersist } from '@/hooks/useRunIssueBannerDismiss';
import {
  RunResultsIssueBanners,
  RunResultsIssuesDialog,
  hasAnyIssueMessages,
} from '@/components/run/RunResultsIssueBanners';
import { ProductGroupSummaryTable } from '@/components/run/ProductGroupSummaryTable';
import { useUserLevelStore, isVisible } from '@/hooks/useUserLevel';
import { scenarioDb } from '@/lib/scenarioDb';
import ScenarioContextBar from '@/components/ScenarioContextBar';
import ChartScenarioLabel from '@/components/ChartScenarioLabel';
import { RechartsTooltipWithTotal } from '@/components/charts/RechartsTooltipWithTotal';
import { NoModelSelected } from '@/components/NoModelSelected';
import { NonNegativeNumericInput } from '@/components/NonNegativeNumericInput';

// ── Scenario color palettes for grouped charts ──
const SCENARIO_PALETTES = [
  { setup: 'hsl(217, 91%, 75%)', run: 'hsl(217, 91%, 55%)', repair: 'hsl(217, 70%, 40%)', waitLabor: 'hsl(217, 60%, 30%)', unavail: 'hsl(217, 30%, 50%)', lotWait: 'hsl(217, 91%, 80%)', queue: 'hsl(217, 70%, 45%)', single: 'hsl(217, 91%, 60%)' },
  { setup: 'hsl(160, 60%, 70%)', run: 'hsl(160, 60%, 45%)', repair: 'hsl(160, 50%, 35%)', waitLabor: 'hsl(160, 40%, 25%)', unavail: 'hsl(160, 25%, 45%)', lotWait: 'hsl(160, 60%, 75%)', queue: 'hsl(160, 50%, 40%)', single: 'hsl(160, 60%, 45%)' },
  { setup: 'hsl(30, 90%, 75%)', run: 'hsl(30, 90%, 55%)', repair: 'hsl(30, 70%, 40%)', waitLabor: 'hsl(30, 60%, 30%)', unavail: 'hsl(30, 30%, 50%)', lotWait: 'hsl(30, 90%, 80%)', queue: 'hsl(30, 70%, 45%)', single: 'hsl(30, 90%, 55%)' },
  { setup: 'hsl(280, 60%, 75%)', run: 'hsl(280, 60%, 55%)', repair: 'hsl(280, 50%, 40%)', waitLabor: 'hsl(280, 40%, 30%)', unavail: 'hsl(280, 25%, 45%)', lotWait: 'hsl(280, 60%, 80%)', queue: 'hsl(280, 50%, 45%)', single: 'hsl(280, 60%, 55%)' },
  { setup: 'hsl(0, 70%, 75%)', run: 'hsl(0, 70%, 55%)', repair: 'hsl(0, 55%, 40%)', waitLabor: 'hsl(0, 45%, 30%)', unavail: 'hsl(0, 25%, 45%)', lotWait: 'hsl(0, 70%, 80%)', queue: 'hsl(0, 55%, 45%)', single: 'hsl(0, 70%, 55%)' },
];

const chartColors = {
  setup: MCT_COLORS.setup, run: MCT_COLORS.run,
  repair: 'hsl(0, 72%, 51%)', waitLabor: MCT_COLORS.waitLabor,
  unavail: 'hsl(220, 9%, 46%)', lotWait: MCT_COLORS.lotWait, queue: MCT_COLORS.waitEquip,
};

type ScenarioEntry = { id: string; name: string; results: CalcResults };

function buildGroupedEquipData(scenarios: ScenarioEntry[]) {
  if (scenarios.length === 0) return { data: [], bars: [] };
  const names = scenarios[0].results.equipment.map(e => e.name);
  const data = names.map(name => {
    const row: Record<string, any> = { name };
    scenarios.forEach((s, i) => {
      const eq = s.results.equipment.find(e => e.name === name);
      const prefix = `s${i}_`;
      row[prefix + 'setup'] = eq?.setupUtil || 0;
      row[prefix + 'run'] = eq?.runUtil || 0;
      row[prefix + 'repair'] = eq?.repairUtil || 0;
      row[prefix + 'waitLabor'] = eq?.waitLaborUtil || 0;
    });
    return row;
  });
  const bars = scenarios.map((s, i) => ({
    prefix: `s${i}_`, stackId: `s${i}`, name: s.name,
    palette: SCENARIO_PALETTES[i % SCENARIO_PALETTES.length],
  }));
  return { data, bars };
}

function buildGroupedLaborData(scenarios: ScenarioEntry[]) {
  if (scenarios.length === 0) return { data: [], bars: [] };
  const names = scenarios[0].results.labor.map(l => l.name);
  const data = names.map(name => {
    const row: Record<string, any> = { name };
    scenarios.forEach((s, i) => {
      const l = s.results.labor.find(l => l.name === name);
      const prefix = `s${i}_`;
      row[prefix + 'setup'] = l?.setupUtil || 0;
      row[prefix + 'run'] = l?.runUtil || 0;
      row[prefix + 'unavail'] = l?.unavailPct || 0;
    });
    return row;
  });
  const bars = scenarios.map((s, i) => ({
    prefix: `s${i}_`, stackId: `s${i}`, name: s.name,
    palette: SCENARIO_PALETTES[i % SCENARIO_PALETTES.length],
  }));
  return { data, bars };
}

function buildGroupedProductMCTData(scenarios: ScenarioEntry[]) {
  if (scenarios.length === 0) return { data: [], bars: [] };
  const names = scenarios[0].results.products.map(p => p.name);
  const data = names.map(name => {
    const row: Record<string, any> = { name };
    scenarios.forEach((s, i) => {
      const p = s.results.products.find(p => p.name === name);
      const prefix = `s${i}_`;
      row[prefix + 'lotWait'] = p?.mctLotWait || 0;
      row[prefix + 'queue'] = p?.mctQueue || 0;
      row[prefix + 'waitLabor'] = p?.mctWaitLabor || 0;
      row[prefix + 'setup'] = p?.mctSetup || 0;
      row[prefix + 'run'] = p?.mctRun || 0;
    });
    return row;
  });
  const bars = scenarios.map((s, i) => ({
    prefix: `s${i}_`, stackId: `s${i}`, name: s.name,
    palette: SCENARIO_PALETTES[i % SCENARIO_PALETTES.length],
  }));
  return { data, bars };
}

function buildGroupedProductWIPData(scenarios: ScenarioEntry[]) {
  if (scenarios.length === 0) return { data: [], bars: [] };
  const names = scenarios[0].results.products.map(p => p.name);
  const data = names.map(name => {
    const row: Record<string, any> = { name };
    scenarios.forEach((s, i) => {
      const p = s.results.products.find(p => p.name === name);
      row[`s${i}_wip`] = p?.wip || 0;
    });
    return row;
  });
  const bars = scenarios.map((s, i) => ({
    prefix: `s${i}_`, stackId: `s${i}`, name: s.name,
    palette: SCENARIO_PALETTES[i % SCENARIO_PALETTES.length],
  }));
  return { data, bars };
}

const Tooltip = RechartsTooltip;
const tooltipStyle = { background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 6, fontSize: 12 };
const axisStyle = { fontSize: 11, fontFamily: 'JetBrains Mono' };
const asNum = (v: unknown, fallback = 0) => {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

const roundHalfUp = (v: unknown, digits: number): number => {
  const n = asNum(v);
  const f = 10 ** digits;
  return Math.round((n + Number.EPSILON) * f) / f;
};

const fmtRound = (v: unknown, digits: number): string => roundHalfUp(v, digits).toFixed(digits);

/* ─── Sortable Table Header ─── */
function SortHead({ label, sortKey, current, onSort, align = 'right' }: {
  label: string; sortKey: string; current: { key: string; dir: SortDir };
  onSort: (k: string) => void; align?: 'left' | 'right';
}) {
  const active = current.key === sortKey && current.dir !== 'default';
  return (
    <TableHead
      className={`font-mono text-xs cursor-pointer select-none hover:text-foreground transition-colors ${align === 'right' ? 'text-right' : 'text-left'}`}
      onClick={() => onSort(sortKey)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {active ? (
          current.dir === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
        ) : (
          <ArrowUpDown className="h-3 w-3 opacity-0 group-hover:opacity-30" />
        )}
      </span>
    </TableHead>
  );
}

/* ─── Production Chart Data Builder ─── */
function buildProductionData(results: CalcResults, model: any) {
  return results.products.map(pr => {
    // Use DLL/backend result fields only (no frontend IBOM-derived math).
    const anyPr = pr as any;
    const totalGoodProd = asNum(anyPr.totalGoodProd ?? anyPr.total_good_prod ?? anyPr.goodMade, asNum(pr.goodMade));
    const shipped = asNum(
      anyPr.shippedProduction ?? anyPr.shippedProd ?? anyPr.shipped,
      asNum(pr.goodShipped),
    );
    const scrappedInAssembly = asNum(
      anyPr.scrappedInAssembly ?? anyPr.scrapInAssembly ?? anyPr.ScrapInAsm ?? anyPr.scrappedInAssy ?? anyPr.scrapInAssy ?? anyPr.ScarpInAsm ?? anyPr.scrapped_in_assembly ?? anyPr.scrap_in_assembly,
      0,
    );
    // Per requirement: Used in Assembly = TotalGoodProd - ScarpInAsm.
    const usedInAssembly = Math.max(0, totalGoodProd - scrappedInAssembly);
    const scrapInProd = asNum(
      anyPr.scrapInProduction ?? anyPr.scrap_in_production,
      asNum(pr.scrap),
    );
    const total = asNum(
      anyPr.totalProduction ?? anyPr.total_production ?? anyPr.total,
      shipped + usedInAssembly + scrappedInAssembly + scrapInProd,
    );
    return {
      name: pr.name,
      shipped: Math.round(shipped),
      usedInAssembly: Math.round(usedInAssembly),
      scrappedInAssembly: Math.round(scrappedInAssembly),
      scrapInProduction: Math.round(scrapInProd),
      total: Math.round(total),
    };
  });
}

type ExtendedRunMode = RunMode | 'max_throughput' | 'lot_size_range' | 'tbatch_range' | 'optimize_lots';

// ═══════════════════════════════════════════════════════════════════════
//  SHARED OPER-METRICS HELPER
//
//  BUG-E FIX: Eq setup/run util — divide raw weighted sum by eq.count
//             NOT by avail_time = count*(1+OT)*t1*t2.
//             Legacy: teq->uset /= teq->num  (line 389)
//
//  BUG-F FIX: Lab setup/run util — divide raw weighted sum by lab.count
//             NOT by avail_lab = count*(1+lab_OT)*t1*t2.
//             Legacy: tlabor->uset /= tlabor->num_av  (line 347)
//             where num_av = num at that point.
//
//  BUG-D FIX: Repair % = (eqSetupUtil + eqRunUtil) * mttr/mttf
//             This is naturally correct once BUG-E is fixed since
//             setup/run are now per-machine fractions.
//             Legacy: teq->udown = (uset+urun)*mttr/mttf  (line 391)
//
//  BUG-G FIX: xbar1 for uwait = raw labor time.
//             LABOR_T divides by lab_OT; legacy line 288 re-multiplies
//             by (1+lab_OT/100), so OT cancels → net = raw.
//             The local code previously used LABOR_T-divided times as-is.
//             (waitLaborUtil is read from results.equipment, not recomputed
//              locally, so BUG-G/H do not apply to the display columns here
//              — they are already correct from the v6 engine.)
//
//  ACCUMULATION PATTERN (matches legacy calc1.cpp lines 284-305, 347-390):
//    v1 = dlam * af * vp * MIN(1, lsize)
//    eq_raw_uset  += v1 * xs_e          (per-lot setup)
//    eq_raw_urun  += v1 * xr_e_lot      (per-lot run = xr_e_pc * MAX(1,lsize))
//    eqSetupUtil  = eq_raw_uset / count  (percent fraction → *100 for display)
//    eqRunUtil    = eq_raw_urun / count
//    repair%      = (eqSetupUtil + eqRunUtil) * mttr/mttf
//
//    lab_raw_uset += v1 * xs_l
//    lab_raw_urun += v1 * xr_l_lot
//    labSetupUtil = lab_raw_uset / lab.count
//    labRunUtil   = lab_raw_urun / lab.count
// ═══════════════════════════════════════════════════════════════════════
type OperMetric = {
  opId: string;
  opName: string;
  opNumber: number;
  productName: string;
  productId: string;
  equipName: string;
  equipId: string;
  laborName: string;
  laborId: string;
  pctAssigned: number;
  eqSetupUtil: number;
  eqRunUtil: number;
  repairUtil: number;
  waitLaborUtil: number;
  labSetupUtil: number;
  labRunUtil: number;
  eqSetupTime: number;
  eqRunTime: number;
  labSetupTime: number;
  labRunTime: number;
  wip: number;
  mctAtOp: number;
  visits: number;
  timeWaitingEquipment: number;
  timeWaitingLabor: number;
  timeInSetup: number;
  timeInRun: number;
  timeWaitingRestOfLot: number;
  visitsPerGoodPiece: number;
  noOfSetups: number;
  avgLotSize: number;
};

function buildOperMetrics(model: Model, results: CalcResults): OperMetric[] {
  const g = model.general;
  const conv1 = Math.max(g.conv1, 0.001);
  const conv2 = Math.max(g.conv2, 0.001);
  const opsPerPeriod = conv1 * conv2;

  // ── Step 1: accumulate raw weighted sums per equipment and labor group ──
  // Key: eq.id or lab.id → raw sum
  const eq_raw_uset: Record<string, number> = {};
  const eq_raw_urun: Record<string, number> = {};
  const lab_raw_uset: Record<string, number> = {};
  const lab_raw_urun: Record<string, number> = {};

  model.operations.forEach(op => {
    const eq = model.equipment.find(e => e.id === op.equip_id);
    const prod = model.products.find(p => p.id === op.product_id);
    const pr = results.products.find(p => p.id === op.product_id);
    if (!eq || !prod || !pr) return;
    const demand = pr.demand;
    if (demand <= 0) return;
    const isDelay = (eq as any).equip_type === 'delay';
    if (isDelay) return;

    const lotSize = Math.max(1, prod.lot_size * (prod.lot_factor || 1));
    const tbatchRaw = prod.tbatch_size === -1 ? lotSize : Math.max(1, prod.tbatch_size);
    const tbatchSize = tbatchRaw;
    const nb = lotSize / tbatchSize; // exact, matches legacy float division
    const lsize = (op as any).lsize != null ? Math.max(0, (op as any).lsize) : lotSize;
    const af = op.pct_assigned / 100;
    if (af <= 0) return;
    const ps_factor = prod.setup_factor || 1;
    const lab = model.labor.find(l => l.id === eq.labor_group_id);
    const eq_ot = 1 + eq.overtime_pct / 100;
    const lab_ot = lab ? (1 + lab.overtime_pct / 100) : 1;
    const eq_sf = eq.setup_factor || 1;
    const eq_rf = eq.run_factor || 1;
    const lab_sf = lab ? (lab.setup_factor || 1) : 1;
    const lab_rf = lab ? (lab.run_factor || 1) : 1;

    // EQUIP_T: xs per-lot, xr per-piece  (both /eq_ot)
    const xs_e = (
      (op.equip_setup_lot || 0)
      + (op.equip_setup_tbatch || 0) * nb
      + (op.equip_setup_piece || 0) * lsize
    ) * eq_sf * ps_factor / eq_ot;
    const xr_e_pc = lsize > 1e-6
      ? ((op.equip_run_lot || 0)
          + (op.equip_run_tbatch || 0) * nb
          + (op.equip_run_piece || 0) * lsize
        ) * eq_rf / eq_ot / lsize
      : 0;
    const xr_e_lot = xr_e_pc * Math.max(1, lsize);  // BUG-E: per-lot

    // LABOR_T: xs per-lot, xr per-piece  (both /lab_ot)
    const xs_l = (
      (op.labor_setup_lot || 0)
      + (op.labor_setup_tbatch || 0) * nb
      + (op.labor_setup_piece || 0) * lsize
    ) * eq_sf * lab_sf * ps_factor / lab_ot;
    const xr_l_pc = lsize > 1e-6
      ? ((op.labor_run_lot || 0)
          + (op.labor_run_tbatch || 0) * nb
          + (op.labor_run_piece || 0) * lsize
        ) * eq_rf * lab_rf / lab_ot / lsize
      : 0;
    const xr_l_lot = xr_l_pc * Math.max(1, lsize);  // BUG-F: per-lot

    // dlam and v1 — match legacy: v1 = dlam * af * vp * MIN(1, lsize)
    const demand_inflated = demand * (1 + (pr as any).scrapRate || 0);  // use inflated if available
    const dlam = demand_inflated > 0
      ? demand_inflated / (lotSize * opsPerPeriod)
      : demand / (lotSize * opsPerPeriod);

    // visit probability: read from results if available, else 1
    const vp = 1.0; // conservative default; real vp is inside the engine
    const v1 = dlam * af * vp * Math.min(1, lsize);

    // Accumulate raw weighted sums (same as legacy teq->uset += v1*xbars)
    eq_raw_uset[eq.id] = (eq_raw_uset[eq.id] || 0) + v1 * xs_e;
    eq_raw_urun[eq.id] = (eq_raw_urun[eq.id] || 0) + v1 * xr_e_lot;

    if (lab) {
      lab_raw_uset[lab.id] = (lab_raw_uset[lab.id] || 0) + v1 * xs_l;
      lab_raw_urun[lab.id] = (lab_raw_urun[lab.id] || 0) + v1 * xr_l_lot;
    }
  });

  // ── Step 2: normalize per-machine (BUG-E/F fix) ──
  const eqSetupUtilMap: Record<string, number> = {};
  const eqRunUtilMap: Record<string, number> = {};
  const eqRepairUtilMap: Record<string, number> = {};

  model.equipment.forEach(eq => {
    const count = eq.count > 0 ? eq.count : 1;
    const mttf = (eq as any).mttf || 0;
    const mttr = (eq as any).mttr || 0;
    // BUG-E FIX: /count, not /avail_time
    const su = (eq_raw_uset[eq.id] || 0) / count;
    const ru = (eq_raw_urun[eq.id] || 0) / count;
    // BUG-D FIX: repair from per-machine fractions
    const rep = mttf > 0 ? (su + ru) * (mttr / mttf) : 0;
    eqSetupUtilMap[eq.id] = su * 100;
    eqRunUtilMap[eq.id]   = ru * 100;
    eqRepairUtilMap[eq.id] = rep * 100;
  });

  const labSetupUtilMap: Record<string, number> = {};
  const labRunUtilMap: Record<string, number> = {};

  model.labor.forEach(lab => {
    const count = lab.count > 0 ? lab.count : 1;
    // BUG-F FIX: /count, not /avail_lab
    const su = (lab_raw_uset[lab.id] || 0) / count;
    const ru = (lab_raw_urun[lab.id] || 0) / count;
    labSetupUtilMap[lab.id] = su * 100;
    labRunUtilMap[lab.id]   = ru * 100;
  });

  // ── Step 3: build per-operation rows ──
  return model.operations.map(op => {
    const eq = model.equipment.find(e => e.id === op.equip_id);
    const prod = model.products.find(p => p.id === op.product_id);
    const pr = results.products.find(p => p.id === op.product_id);
    const er = eq ? results.equipment.find(e => e.id === eq.id) : null;
    const lab = eq ? model.labor.find(l => l.id === eq.labor_group_id) : null;
    if (!prod || !eq) return null;
    const demand = pr?.demand ?? prod.demand ?? 0;

    const lotSize = Math.max(1, prod.lot_size * (prod.lot_factor || 1));
    const tbatchRaw = prod.tbatch_size === -1 ? lotSize : Math.max(1, prod.tbatch_size);
    const nb = lotSize / tbatchRaw;
    const lsize = (op as any).lsize != null ? Math.max(0, (op as any).lsize) : lotSize;
    const assignFrac = op.pct_assigned / 100;
    const ps_factor = prod.setup_factor || 1;
    const eq_sf = eq.setup_factor || 1;
    const eq_rf = eq.run_factor || 1;
    const eq_ot = 1 + eq.overtime_pct / 100;
    const lab_sf = lab ? (lab.setup_factor || 1) : 1;
    const lab_rf = lab ? (lab.run_factor || 1) : 1;
    const lab_ot = lab ? (1 + lab.overtime_pct / 100) : 1;

    // Raw time accumulators (for time-unit display only)
    const demand_inflated = demand;
    const numLots = demand > 0 ? (demand_inflated / lotSize) * assignFrac : 0;
    const eqSetupTime = numLots * (
      (op.equip_setup_lot || 0)
      + (op.equip_setup_tbatch || 0) * nb
      + (op.equip_setup_piece || 0) * lsize
    ) * eq_sf * ps_factor / eq_ot;
    const eqRunTime = numLots * (
      (op.equip_run_lot || 0)
      + (op.equip_run_tbatch || 0) * nb
      + (op.equip_run_piece || 0) * lsize
    ) * eq_rf / eq_ot;
    const labSetupTime = lab ? numLots * (
      (op.labor_setup_lot || 0)
      + (op.labor_setup_tbatch || 0) * nb
      + (op.labor_setup_piece || 0) * lsize
    ) * eq_sf * lab_sf * ps_factor / lab_ot : 0;
    const labRunTime = lab ? numLots * (
      (op.labor_run_lot || 0)
      + (op.labor_run_tbatch || 0) * nb
      + (op.labor_run_piece || 0) * lsize
    ) * eq_rf * lab_rf / lab_ot : 0;

    // Per-operation util contribution (for display; total is from engine results)
    // Read per-op util from engine results where available (most accurate),
    // fall back to local proportion for oper-details display.
    const oprResult = results.operations
      ? results.operations.find((o: any) =>
          String(o.product_id ?? '') === String(op.product_id) &&
          (
            String(o.op_id ?? o.opId ?? '') === String(op.id) ||
            (asNum(o.op_number) > 0 && asNum(o.op_number) === asNum((op as any).op_number)) ||
            String(o.operation ?? o.op_name ?? '') === String(op.op_name)
          )
        )
      : null;

    // BUG-E/F FIX: use engine results (ueset/uerun/ulset/ulrun) if present,
    // otherwise use locally-computed values from the corrected formula above.
    const eqSetupUtil = oprResult
      ? Number(oprResult.ueset || 0)
      : (eqSetupUtilMap[eq.id] || 0);
    const eqRunUtil = oprResult
      ? Number(oprResult.uerun || 0)
      : (eqRunUtilMap[eq.id] || 0);
    const repairUtil = er?.repairUtil || eqRepairUtilMap[eq.id] || 0;
    const labSetupUtil = oprResult
      ? Number(oprResult.ulset || 0)
      : (labSetupUtilMap[lab?.id || ''] || 0);
    const labRunUtil = oprResult
      ? Number(oprResult.ulrun || 0)
      : (labRunUtilMap[lab?.id || ''] || 0);

    const allOpsForProd = model.operations.filter((o: any) => o.product_id === op.product_id);
    const wipShare = oprResult ? Number(oprResult.qpoper || 0) : ((pr?.wip ?? 0) / Math.max(1, allOpsForProd.length));

    // MCT at op: use engine flowtime if available, else approximate
    const mctAtOp = oprResult
      ? oprResult.flowtime_shifts || (oprResult.flowtime / Math.max(g.conv1, 0.001))
      : 0;

    const visits = oprResult
      ? Number(oprResult.visits_per_100 || (Number(oprResult.visit_prob || 0) * 100))
      : (demand > 0 ? (numLots * lotSize / demand) * 100 : 100);

    const timeWaitingEquipment = oprResult ? Number(oprResult.w_equip || 0) : 0;
    const timeWaitingLabor = oprResult ? Number(oprResult.w_labor || 0) : 0;
    const timeInSetup = oprResult ? Number(oprResult.w_setup || 0) : 0;
    const timeInRun = oprResult ? Number(oprResult.w_run || 0) : 0;
    const timeWaitingRestOfLot = oprResult ? Number(oprResult.w_lot || 0) : 0;
    const visitsPerGoodPiece = oprResult ? Number(oprResult.visits_per_good || 0) : 0;
    const noOfSetups = oprResult ? Number(oprResult.n_setups || 0) : 0;
    const avgLotSize = oprResult ? Number(oprResult.avg_lot_size || 0) : lsize;

    return {
      opId: op.id,
      opName: op.op_name,
      opNumber: (op as any).op_number || 0,
      productName: prod.name, productId: prod.id,
      equipName: eq.name, equipId: eq.id,
      laborName: lab?.name || '—', laborId: lab?.id || '',
      pctAssigned: op.pct_assigned,
      // ── Utilisation columns — all BUG-E/F/D fixed ──
      eqSetupUtil: Math.round(eqSetupUtil * 10) / 10,
      eqRunUtil:   Math.round(eqRunUtil   * 10) / 10,
      repairUtil:  Math.round(repairUtil   * 10) / 10,
      // waitLaborUtil always comes from engine results (BUG-G/H already fixed in v6)
      waitLaborUtil: er?.waitLaborUtil || 0,
      labSetupUtil: Math.round(labSetupUtil * 10) / 10,
      labRunUtil:   Math.round(labRunUtil   * 10) / 10,
      // Raw times (for time-unit toggle)
      eqSetupTime:  Math.round(eqSetupTime  * 1000) / 1000,
      eqRunTime:    Math.round(eqRunTime    * 1000) / 1000,
      labSetupTime: Math.round(labSetupTime * 1000) / 1000,
      labRunTime:   Math.round(labRunTime   * 1000) / 1000,
      // Other columns
      wip:     Math.round(wipShare * 10) / 10,
      mctAtOp: Math.round(mctAtOp * 10000) / 10000,
      visits:  Math.round(visits  * 10) / 10,
      timeWaitingEquipment: Math.round(timeWaitingEquipment * 10000) / 10000,
      timeWaitingLabor: Math.round(timeWaitingLabor * 10000) / 10000,
      timeInSetup: Math.round(timeInSetup * 10000) / 10000,
      timeInRun: Math.round(timeInRun * 10000) / 10000,
      timeWaitingRestOfLot: Math.round(timeWaitingRestOfLot * 10000) / 10000,
      visitsPerGoodPiece: Math.round(visitsPerGoodPiece * 10000) / 10000,
      noOfSetups: Math.round(noOfSetups * 10000) / 10000,
      avgLotSize: Math.round(avgLotSize * 10000) / 10000,
    };
  }).filter((row): row is OperMetric => row !== null);
}

export default function RunResults() {
  const model = useModelStore(s => s.getActiveModel());
  const allScenarios = useScenarioStore(s => s.scenarios);
  const activeScenarioId = useScenarioStore(s => s.activeScenarioId);
  const displayIds = useScenarioStore(s => s.displayScenarioIds);
  const { getResults } = useResultsStore();
  const selectedRunScenarioId = useResultsStore(s => s.selectedRunScenarioId);
  const setSelectedRunScenarioId = useResultsStore(s => s.setSelectedRunScenarioId);
  const { userLevel, loading, fetchUserLevel } = useUserLevelStore();

  useEffect(() => {
    if (loading) fetchUserLevel();
  }, [loading, fetchUserLevel]);

  const { isRunning, runLog, verifyMessages, showIssueBanners, handleRun } = useRunCalculation();
  const [issuesDialogOpen, setIssuesDialogOpen] = useState(false);

  const [extRunMode, setExtRunMode] = useState<ExtendedRunMode>('full');
  const runMode: RunMode = (extRunMode === 'full' || extRunMode === 'verify' || extRunMode === 'util_only') ? extRunMode : 'full';
  const [transposed, setTransposed] = useState(false);

  const [mtProduct, setMtProduct] = useState(model?.products[0]?.id || '');
  const [mtScenarioName, setMtScenarioName] = useState('');
  const [mtResult, setMtResult] = useState<{demand: number; limitingResource: string} | null>(null);
  const [lsrProduct, setLsrProduct] = useState(model?.products[0]?.id || '');
  const [lsrMin, setLsrMin] = useState(10);
  const [lsrMax, setLsrMax] = useState(200);
  const [lsrStep, setLsrStep] = useState(10);
  const [lsrResults, setLsrResults] = useState<{lotSize: number; mct: number}[]>([]);
  const [tbrProduct, setTbrProduct] = useState(model?.products[0]?.id || '');
  const [tbrMin, setTbrMin] = useState(1);
  const [tbrMax, setTbrMax] = useState(50);
  const [tbrStep, setTbrStep] = useState(5);
  const [tbrResults, setTbrResults] = useState<{tbatch: number; mct: number}[]>([]);
  const [optProducts, setOptProducts] = useState<Set<string>>(new Set(model?.products.map(p => p.id) || []));
  const [optResult, setOptResult] = useState<{original: {name:string;lot:number;wip:number}[]; optimized: {name:string;lot:number;wip:number}[]; wipReduction: number} | null>(null);
  const [advProgress, setAdvProgress] = useState<{current:number; total:number; label:string} | null>(null);
  const [advRunning, setAdvRunning] = useState(false);

  const [mtModalOpen, setMtModalOpen] = useState(false);
  const [mtModalMode, setMtModalMode] = useState<'max_throughput' | 'lot_size_range'>('max_throughput');
  const [mtModalProduct, setMtModalProduct] = useState(model?.products[0]?.id || '');
  const [mtModalName, setMtModalName] = useState('');
  const [mtModalLsFrom, setMtModalLsFrom] = useState(10);
  const [mtModalLsTo, setMtModalLsTo] = useState(200);
  const [mtModalLsStep, setMtModalLsStep] = useState(10);

  const [olModalOpen, setOlModalOpen] = useState(false);
  const [olName, setOlName] = useState('Optimised Lot Sizes');
  const [olUnitValues, setOlUnitValues] = useState<Record<string, number>>({});
  const [olOptLot, setOlOptLot] = useState<Set<string>>(new Set());
  const [olOptTb, setOlOptTb] = useState<Set<string>>(new Set());
  const [olInitialWip, setOlInitialWip] = useState<number | null>(null);
  const [olCurrentWip, setOlCurrentWip] = useState<number | null>(null);

  const { createScenario } = useScenarioStore();
  const { setResults: setStoreResults } = useResultsStore();

  const activeScenario = model ? (allScenarios.find(s => s.id === activeScenarioId) || null) : null;
  const modelScenarios = model ? allScenarios.filter(s => s.modelId === model.id) : [];
  const resultKey = selectedRunScenarioId && selectedRunScenarioId !== 'basecase'
    ? selectedRunScenarioId
    : (activeScenario ? activeScenario.id : 'basecase');
  const results = getResults(resultKey);
  const basecaseResults = getResults('basecase');
  const hasRun = !!results;

  // Tie dismiss persistence to results.calculatedAt only (not last_run_at — formats differ and
  // last_run can update without changing saved results). Pending until results hydrate after refresh.
  const resultsStamp =
    (results?.calculatedAt || (model ? `pending:${resultKey}` : '')) as string;
  const issueDismissPersist = useMemo((): RunIssueDismissPersist | null => {
    if (!model) return null;
    return { modelId: model.id, resultKey, resultsStamp };
  }, [model, resultKey, resultsStamp]);

  const { dismissed: dismissedIssueBanners, dismiss: dismissIssueBanner, clearDismiss } =
    useRunIssueBannerDismiss(runLog, issueDismissPersist);

  const chartScenarios: ScenarioEntry[] = useMemo(() => {
    const entries: ScenarioEntry[] = [];
    if (basecaseResults) entries.push({ id: 'basecase', name: 'Basecase', results: basecaseResults });
    displayIds.forEach(id => {
      const sc = modelScenarios.find(s => s.id === id);
      const r = getResults(id);
      if (sc && r && id !== 'basecase') entries.push({ id, name: sc.name, results: r });
    });
    return entries;
  }, [basecaseResults, displayIds, modelScenarios, getResults]);

  const isMultiScenario = chartScenarios.length > 1;

  const displayScenarioResults = useMemo(() => displayIds
    .map(id => ({ id, scenario: modelScenarios.find(s => s.id === id), results: getResults(id) }))
    .filter(d => d.scenario && d.results) as { id: string; scenario: typeof modelScenarios[0]; results: CalcResults }[],
    [displayIds, modelScenarios, getResults]);

  const equipChartData = useMemo(() => results?.equipment.map(e => ({
    name: e.name, setup: e.setupUtil, run: e.runUtil, repair: e.repairUtil, waitLabor: e.waitLaborUtil,
  })) || [], [results]);

  const laborChartData = useMemo(() => results?.labor.map(l => ({
    name: l.name, setup: l.setupUtil, run: l.runUtil, unavail: l.unavailPct,
  })) || [], [results]);

  const productChartData = useMemo(() => results?.products.map(p => ({
    name: p.name, lotWait: p.mctLotWait, queue: p.mctQueue, waitLabor: p.mctWaitLabor, setup: p.mctSetup, run: p.mctRun,
  })) || [], [results]);

  const groupedEquip = useMemo(() => isMultiScenario ? buildGroupedEquipData(chartScenarios) : null, [isMultiScenario, chartScenarios]);
  const groupedLabor = useMemo(() => isMultiScenario ? buildGroupedLaborData(chartScenarios) : null, [isMultiScenario, chartScenarios]);
  const groupedMCT   = useMemo(() => isMultiScenario ? buildGroupedProductMCTData(chartScenarios) : null, [isMultiScenario, chartScenarios]);
  const groupedWIP   = useMemo(() => isMultiScenario ? buildGroupedProductWIPData(chartScenarios) : null, [isMultiScenario, chartScenarios]);

  const isAdvancedMode = ['max_throughput', 'lot_size_range', 'tbatch_range', 'optimize_lots'].includes(extRunMode);

  const [activeTab, setActiveTab]       = useState('summary');
  const [equipSubTab, setEquipSubTab]   = useState('util-chart');
  const [laborSubTab, setLaborSubTab]   = useState('util-chart');
  const [productsSubTab, setProductsSubTab] = useState('mct-chart');
  const [ibomSubTab, setIbomSubTab]     = useState('tree-chart');

  const lastRunMode = runLog.length > 0 ? runLog[0].mode : null;
  const isUtilOnly = lastRunMode === 'util_only' || isUtilOnlyCalcResults(results);
  const validationOnlyPanel = lastRunMode === 'verify';

  const prevRunLogLenRef = useRef(runLog.length);
  const wasViewingTabRef = useRef(activeTab);
  useEffect(() => { wasViewingTabRef.current = activeTab; }, [activeTab]);
  useEffect(() => {
    if (runLog.length > prevRunLogLenRef.current) {
      const latest = runLog[0];
      if (latest && latest.mode === 'full' && latest.status !== 'error') {
        if (wasViewingTabRef.current === 'summary') setActiveTab('summary');
      }
    }
    prevRunLogLenRef.current = runLog.length;
  }, [runLog.length]);

  if (!model) return <NoModelSelected />;

  const statusChip = isRunning || advRunning
    ? { label: 'Running…', color: 'bg-info/15 text-info border-info/30', icon: <span className="animate-spin inline-block h-3 w-3 border-2 border-info border-t-transparent rounded-full" /> }
    : model.run_status === 'needs_recalc' && hasRun
    ? { label: 'Recalc Needed', color: 'bg-amber-100 text-amber-800 border-amber-200', icon: <AlertTriangle className="h-3 w-3" /> }
    : { label: 'Ready', color: 'bg-emerald-50 text-emerald-800 border-emerald-200', icon: <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" /> };

  const lastRunText = model.last_run_at ? `Last run: ${new Date(model.last_run_at).toLocaleString()}` : 'Never run';

  const canShowIssueBanners =
    showIssueBanners &&
    !isRunning &&
    !advRunning &&
    hasAnyIssueMessages(results, verifyMessages, { validationOnly: validationOnlyPanel });

  return (
    <div className="h-full flex flex-col overflow-hidden animate-fade-in">
      {/* ── Page Header Row ── */}
      <div className="flex items-center justify-between pb-4 shrink-0">
        <h1 className="text-2xl font-bold text-slate-900">Run & Results</h1>
        {activeScenario && (
          <Badge variant="outline" className="border-warning/50 bg-warning/10 text-warning gap-1.5 text-xs font-medium">
            <span className="inline-block h-2 w-2 rounded-full bg-warning" />
            {activeScenario.name}
          </Badge>
        )}
      </div>

      {/* ── Run Control Bar ── */}
      <div className="min-h-[52px] h-auto shrink-0 flex flex-wrap items-center gap-2 md:gap-3 py-2 bg-slate-100/80 border border-slate-200 rounded-lg px-3 md:px-4 mb-6">
        <Button
          size="sm"
          className="h-9 gap-1.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white"
          onClick={() => {
            clearDismiss();
            handleRun('full');
          }}
          disabled={isRunning || advRunning}
        >
          {isRunning || advRunning ? (
            <><span className="animate-spin h-3.5 w-3.5 border-2 border-primary-foreground border-t-transparent rounded-full" /> Running…</>
          ) : (
            <><Play className="h-3.5 w-3.5" /> Full Calculate</>
          )}
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="h-9 gap-1.5 px-3 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
          onClick={() => {
            clearDismiss('validations');
            handleRun('verify');
          }}
          disabled={isRunning || advRunning}
        >
          <CheckCircle className="h-3.5 w-3.5" /> Verify Data
        </Button>
        {isVisible('calculate_util_only', userLevel) && (
          <TooltipProvider>
            <ShadTooltip>
              <TooltipTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-9 gap-1.5 px-3"
                  onClick={() => {
                    clearDismiss();
                    handleRun('util_only');
                  }}
                  disabled={isRunning || advRunning}
                >
                  <Gauge className="h-3.5 w-3.5" /> Calc. Util Only
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">Calculates equipment and labor utilisation only — faster than Full Calculate.</TooltipContent>
            </ShadTooltip>
          </TooltipProvider>
        )}

        {isVisible('max_throughput', userLevel) && <div className="h-[60%] w-px bg-border self-center" />}

        {isVisible('max_throughput', userLevel) && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="ghost" className="h-9 gap-1.5 px-3 text-xs">
                <Settings2 className="h-3.5 w-3.5" /> Advanced <ChevronRight className="h-3 w-3 rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64">
              <DropdownMenuItem onClick={() => {
                setMtModalProduct(model?.products[0]?.id || '');
                setMtModalName('');
                setMtModalMode('max_throughput');
                setMtModalLsFrom(10); setMtModalLsTo(200); setMtModalLsStep(10);
                setMtModalOpen(true);
              }}>
                <TrendingUp className="h-4 w-4 mr-2" /> Max Throughput + Lot Size Range…
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                const vals: Record<string, number> = {};
                model?.products.forEach(p => { vals[p.id] = 1; });
                setOlUnitValues(vals);
                setOlOptLot(new Set(model?.products.map(p => p.id) || []));
                setOlOptTb(new Set(model?.products.map(p => p.id) || []));
                setOlName('Optimised Lot Sizes');
                const baseCalc = calculate(model!);
                const initWip = baseCalc.products.reduce((s, pr) => s + pr.wip * (vals[pr.id] || 1), 0);
                setOlInitialWip(Math.round(initWip * 100) / 100);
                setOlCurrentWip(null);
                setOlModalOpen(true);
              }}>
                <Settings2 className="h-4 w-4 mr-2" /> Optimise Lot Sizes &amp; Transfer Batches…
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {}}>
                <AlertTriangle className="h-4 w-4 mr-2" /> Errors &amp; Warning Messages
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        <div className="h-[60%] w-px bg-border self-center" />
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] text-muted-foreground whitespace-nowrap">Running for:</span>
          <Select value={selectedRunScenarioId} onValueChange={setSelectedRunScenarioId}>
            <SelectTrigger className={`h-7 w-auto min-w-[140px] max-w-[220px] text-xs gap-1 ${selectedRunScenarioId !== 'basecase' ? 'text-warning border-warning/40' : ''}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="basecase">
                <span className="flex items-center gap-1.5 text-muted-foreground"><Lock className="h-3 w-3" /> Basecase</span>
              </SelectItem>
              {modelScenarios.map((sc, idx) => (
                <SelectItem key={sc.id} value={sc.id}>
                  <span className="flex items-center gap-1.5">
                    <span className="inline-block h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: getScenarioColor(idx) }} />
                    {sc.name}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex-1" />
        <RunResultsIssuesDialog
          open={issuesDialogOpen}
          onOpenChange={setIssuesDialogOpen}
          results={results}
          validationMessages={verifyMessages}
          validationOnly={validationOnlyPanel}
        />
        {canShowIssueBanners && (
          <TooltipProvider>
            <ShadTooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 shrink-0 border-amber-300 text-amber-800 bg-amber-50 hover:bg-amber-100"
                  onClick={() => setIssuesDialogOpen(true)}
                  aria-label="View errors and warnings"
                >
                  <AlertTriangle className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">
                View errors and warnings from the latest run
              </TooltipContent>
            </ShadTooltip>
          </TooltipProvider>
        )}
        <Badge variant="outline" className={`gap-1.5 text-xs font-medium ${statusChip.color}`}>
          {statusChip.icon}{statusChip.label}
        </Badge>
        <span className="text-xs text-muted-foreground whitespace-nowrap">{lastRunText}</span>
      </div>

      {/* ── Primary Tab Bar ── */}
      <div className="shrink-0 border-b border-slate-200">
        <div className="flex h-10 items-center gap-0">
          {(['summary', 'equipment', 'labor', 'products', 'ibom'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`h-10 px-4 text-sm capitalize relative transition-colors ${activeTab === tab ? 'text-slate-900 font-semibold' : 'text-slate-500 font-medium hover:text-slate-900'}`}>
              {tab === 'ibom' ? 'IBOM' : tab}
              {activeTab === tab && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600" />}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content Panel ── */}
      <div className="flex-1 overflow-y-auto overflow-x-auto px-3 md:px-4 lg:px-6 py-4 bg-white">
        {showIssueBanners && !isRunning && !advRunning && (
          <RunResultsIssueBanners
            results={results}
            validationMessages={verifyMessages}
            validationOnly={validationOnlyPanel}
            dismissed={dismissedIssueBanners}
            onDismiss={dismissIssueBanner}
          />
        )}

        {/* ── Summary Tab ── */}
        {activeTab === 'summary' && (
          <>
            <ScenarioContextBar />
            {!isUtilOnly && (
            <div className="grid grid-cols-1 md:grid-cols-2 2xl:grid-cols-4 gap-3 md:gap-4 mb-6">
              <QuickStatCard label="Most loaded equipment"
                value={results ? ([...results.equipment].sort((a,b) => b.totalUtil - a.totalUtil)[0]?.name ?? '—') : '—'}
                metric={results ? (() => { const top = [...results.equipment].sort((a, b) => b.totalUtil - a.totalUtil)[0]; return top?.totalUtil != null ? top.totalUtil.toFixed(1) + '%' : ''; })() : ''} />
              <QuickStatCard label="Most loaded labor"
                value={results ? ([...results.labor].sort((a,b) => b.totalUtil - a.totalUtil)[0]?.name ?? '—') : '—'}
                metric={results ? (() => { const top = [...results.labor].sort((a, b) => b.totalUtil - a.totalUtil)[0]; return top?.totalUtil != null ? top.totalUtil.toFixed(1) + '%' : ''; })() : ''} />
              <QuickStatCard label="Highest MCT product"
                value={results ? ([...results.products].sort((a,b) => b.mct - a.mct)[0]?.name ?? '—') : '—'}
                metric={results ? ([...results.products].sort((a,b) => b.mct - a.mct)[0]?.mct.toFixed(4) ?? '') : ''} />
              <QuickStatCard label="Total system WIP"
                value={results ? Math.round(results.products.reduce((s,p) => s+p.wip,0)).toLocaleString() : '—'}
                metric={results ? 'pieces' : ''} />
            </div>
            )}
            {!hasRun ? <NoResultsPlaceholder /> : (
              <>
                {isUtilOnly && (
                  <UtilOnlyBanner message="Utilization-only run: production counts are shown below. MCT and WIP are zero until you run Full Calculate." />
                )}
                {!isUtilOnly && results &&
                  results.overLimitResources.length === 0 &&
                  results.errors.length === 0 &&
                  (results.warnings?.length ?? 0) === 0 && (
                  <div className="flex items-center gap-2 p-4 mb-6 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
                    <span className="text-sm font-medium text-emerald-600">All production targets can be achieved. Results are current.</span>
                  </div>
                )}
                <Card className="rounded-lg border border-slate-200 bg-white shadow-sm">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-base font-semibold text-slate-900">Output Summary</CardTitle>
                        <CardDescription className="text-slate-500 text-sm mt-0.5">
                          Consolidated production metrics{displayScenarioResults.length > 0 && ` — comparing ${displayScenarioResults.length} scenario(s)`}
                        </CardDescription>
                      </div>
                      <Button variant="outline" size="sm" className="gap-1.5 rounded-full px-3 text-xs" onClick={() => setTransposed(!transposed)}>
                        <RotateCcw className="h-3.5 w-3.5" /> {transposed ? 'Normal View' : 'Transpose'}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0 overflow-x-auto">
                    {transposed
                      ? <TransposedSummary results={results!} model={model} scenarioResults={displayScenarioResults} isUtilOnly={isUtilOnly} />
                      : <NormalSummary results={results!} model={model} scenarioResults={displayScenarioResults} isUtilOnly={isUtilOnly} />}
                  </CardContent>
                </Card>
              </>
            )}
          </>
        )}

        {/* ── Equipment Tab ── */}
        {activeTab === 'equipment' && (!hasRun ? <NoResultsPlaceholder /> : (
          <div className="flex flex-col h-full">
            <div className="flex h-8 items-center gap-0 border-b border-border/50 -mx-3 md:-mx-4 lg:-mx-6 px-3 md:px-4 lg:px-6 mb-6 shrink-0 overflow-x-auto">
              {([
                { key: 'util-chart', label: 'Util Chart' },
                { key: 'results-table', label: 'Results Table' },
                { key: 'wip-chart', label: 'WIP Chart' },
                ...(isVisible('oper_details', userLevel) ? [{ key: 'oper-details', label: 'Oper Details' }] : []),
              ] as const).map(st => (
                <button key={st.key} onClick={() => setEquipSubTab(st.key)}
                  className={`h-8 px-4 text-[13px] relative transition-colors ${equipSubTab === st.key ? 'text-foreground font-medium' : 'text-muted-foreground hover:text-foreground'}`}>
                  {st.label}
                  {equipSubTab === st.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary/60" />}
                </button>
              ))}
            </div>
            <ScenarioContextBar />
            {equipSubTab === 'util-chart' && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Equipment Utilization</CardTitle>
                  <CardDescription>{isMultiScenario ? `Comparing ${chartScenarios.length} scenarios — grouped stacked bars` : 'Stacked utilization breakdown by equipment group'}</CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  <ChartScenarioLabel />
                  <ResponsiveContainer width="100%" height={350}>
                    {isMultiScenario && groupedEquip ? (
                      <BarChart data={groupedEquip.data} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: '% Utilization', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                        <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                        <ReferenceLine y={model.general.util_limit} stroke="hsl(0, 72%, 51%)" strokeDasharray="5 5" label={{ value: `Limit ${model.general.util_limit}%`, position: 'right', style: { fontSize: 10, fill: 'hsl(0, 72%, 51%)' } }} />
                        {groupedEquip.bars.map(b => <Bar key={b.prefix+'setup'} dataKey={b.prefix+'setup'} stackId={b.stackId} fill={b.palette.setup} name={`${b.name} Setup`} />)}
                        {groupedEquip.bars.map(b => <Bar key={b.prefix+'run'} dataKey={b.prefix+'run'} stackId={b.stackId} fill={b.palette.run} name={`${b.name} Run`} />)}
                        {groupedEquip.bars.map(b => <Bar key={b.prefix+'repair'} dataKey={b.prefix+'repair'} stackId={b.stackId} fill={b.palette.repair} name={`${b.name} Repair`} />)}
                        {groupedEquip.bars.map(b => <Bar key={b.prefix+'waitLabor'} dataKey={b.prefix+'waitLabor'} stackId={b.stackId} fill={b.palette.waitLabor} name={`${b.name} Wait Labor`} radius={[2,2,0,0]} />)}
                      </BarChart>
                    ) : (
                      <BarChart data={equipChartData} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: '% Utilization', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                        <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                        <ReferenceLine y={model.general.util_limit} stroke="hsl(0, 72%, 51%)" strokeDasharray="5 5" label={{ value: `Limit ${model.general.util_limit}%`, position: 'right', style: { fontSize: 10, fill: 'hsl(0, 72%, 51%)' } }} />
                        <Bar dataKey="setup" stackId="a" fill={chartColors.setup} name="Setup" />
                        <Bar dataKey="run" stackId="a" fill={chartColors.run} name="Run" />
                        <Bar dataKey="repair" stackId="a" fill={chartColors.repair} name="Repair" />
                        <Bar dataKey="waitLabor" stackId="a" fill={chartColors.waitLabor} name="Wait for Labor" radius={[2,2,0,0]} />
                      </BarChart>
                    )}
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
            {equipSubTab === 'results-table' && <EquipmentResultsTable equipment={results!.equipment} utilLimit={model.general.util_limit} />}
            {equipSubTab === 'wip-chart' && <EquipmentWIPChart results={results!} model={model} isMultiScenario={isMultiScenario} chartScenarios={chartScenarios} />}
            {equipSubTab === 'oper-details' && isVisible('oper_details', userLevel) && (
              <EquipOperDetails model={model} results={results!} />
            )}
          </div>
        ))}

        {/* ── Labor Tab ── */}
        {activeTab === 'labor' && (!hasRun ? <NoResultsPlaceholder /> : (
          <div className="flex flex-col h-full">
            <div className="flex h-8 items-center gap-0 border-b border-border/50 -mx-3 md:-mx-4 lg:-mx-6 px-3 md:px-4 lg:px-6 mb-6 shrink-0 overflow-x-auto">
              {([
                { key: 'util-chart', label: 'Util Chart' },
                { key: 'results-table', label: 'Results Table' },
                { key: 'equip-wait', label: 'Equip Wait Chart' },
                ...(isVisible('oper_details', userLevel) ? [{ key: 'oper-details', label: 'Oper Details' }] : []),
              ] as const).map(st => (
                <button key={st.key} onClick={() => setLaborSubTab(st.key)}
                  className={`h-8 px-4 text-[13px] relative transition-colors ${laborSubTab === st.key ? 'text-foreground font-medium' : 'text-muted-foreground hover:text-foreground'}`}>
                  {st.label}
                  {laborSubTab === st.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary/60" />}
                </button>
              ))}
            </div>
            <ScenarioContextBar />
            {laborSubTab === 'util-chart' && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Labor Utilization</CardTitle>
                  <CardDescription>{isMultiScenario ? `Comparing ${chartScenarios.length} scenarios` : 'Utilization breakdown by labor group'}</CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  <ChartScenarioLabel />
                  <ResponsiveContainer width="100%" height={300}>
                    {isMultiScenario && groupedLabor ? (
                      <BarChart data={groupedLabor.data} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                        <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                        <ReferenceLine y={model.general.util_limit} stroke="hsl(0, 72%, 51%)" strokeDasharray="5 5" />
                        {groupedLabor.bars.map(b => <Bar key={b.prefix+'setup'} dataKey={b.prefix+'setup'} stackId={b.stackId} fill={b.palette.setup} name={`${b.name} Setup`} />)}
                        {groupedLabor.bars.map(b => <Bar key={b.prefix+'run'} dataKey={b.prefix+'run'} stackId={b.stackId} fill={b.palette.run} name={`${b.name} Run`} />)}
                        {groupedLabor.bars.map(b => <Bar key={b.prefix+'unavail'} dataKey={b.prefix+'unavail'} stackId={b.stackId} fill={b.palette.unavail} name={`${b.name} Unavail`} radius={[2,2,0,0]} />)}
                      </BarChart>
                    ) : (
                      <BarChart data={laborChartData} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                        <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                        <ReferenceLine y={model.general.util_limit} stroke="hsl(0, 72%, 51%)" strokeDasharray="5 5" />
                        <Bar dataKey="setup" stackId="a" fill={chartColors.setup} name="Setup" />
                        <Bar dataKey="run" stackId="a" fill={chartColors.run} name="Run" />
                        <Bar dataKey="unavail" stackId="a" fill={chartColors.unavail} name="Unavailable" radius={[2,2,0,0]} />
                      </BarChart>
                    )}
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
            {laborSubTab === 'results-table' && <LaborResultsTable labor={results!.labor} utilLimit={model.general.util_limit} />}
            {laborSubTab === 'equip-wait' && (
              <>
                <p className="text-xs text-muted-foreground mb-4">Shows the average number of machines waiting for each labor group. Large values indicate understaffing or misallocated labor.</p>
                <LaborWaitChart results={results!} model={model} />
              </>
            )}
            {laborSubTab === 'oper-details' && isVisible('oper_details', userLevel) && (
              <LaborOperDetails model={model} results={results!} />
            )}
          </div>
        ))}

        {/* ── Products Tab ── */}
        {activeTab === 'products' && (!hasRun ? <NoResultsPlaceholder /> : (
          <div className="flex flex-col h-full">
            <div className="flex h-8 items-center gap-0 border-b border-border/50 -mx-3 md:-mx-4 lg:-mx-6 px-3 md:px-4 lg:px-6 mb-6 shrink-0 overflow-x-auto">
              {([
                { key: 'mct-chart', label: 'MCT Chart' },
                { key: 'results-table', label: 'Results Table' },
                { key: 'production-chart', label: 'Production Chart' },
                { key: 'wip-chart', label: 'WIP Chart' },
                ...(isVisible('oper_details', userLevel) ? [{ key: 'oper-details', label: 'Oper Details' }] : []),
              ] as const).map(st => (
                <button key={st.key} onClick={() => setProductsSubTab(st.key)}
                  className={`h-8 px-4 text-[13px] relative transition-colors ${productsSubTab === st.key ? 'text-foreground font-medium' : 'text-muted-foreground hover:text-foreground'}`}>
                  {st.label}
                  {productsSubTab === st.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary/60" />}
                </button>
              ))}
            </div>
            <ScenarioContextBar />
            {productsSubTab === 'mct-chart' && (
              <>
                {isUtilOnly && <UtilOnlyBanner />}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Product MCT (Manufacturing Cycle Time)</CardTitle>
                    <CardDescription>{isMultiScenario ? `Comparing ${chartScenarios.length} scenarios — MCT in ${model.general.mct_time_unit}s` : `MCT breakdown by product in ${model.general.mct_time_unit}s`}</CardDescription>
                  </CardHeader>
                  <CardContent className="relative">
                    <ChartScenarioLabel />
                    <ResponsiveContainer width="100%" height={350}>
                      {isMultiScenario && groupedMCT ? (
                        <BarChart data={groupedMCT.data} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                          <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: `MCT (${model.general.mct_time_unit})`, angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                          <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                          {groupedMCT.bars.map(b => <Bar key={b.prefix+'lotWait'}  dataKey={b.prefix+'lotWait'}  stackId={b.stackId} fill={b.palette.lotWait}   name={`${b.name} Lot Wait`} />)}
                          {groupedMCT.bars.map(b => <Bar key={b.prefix+'queue'}    dataKey={b.prefix+'queue'}    stackId={b.stackId} fill={b.palette.queue}     name={`${b.name} Queue`} />)}
                          {groupedMCT.bars.map(b => <Bar key={b.prefix+'waitLabor'} dataKey={b.prefix+'waitLabor'} stackId={b.stackId} fill={b.palette.waitLabor} name={`${b.name} Wait Labor`} />)}
                          {groupedMCT.bars.map(b => <Bar key={b.prefix+'setup'}   dataKey={b.prefix+'setup'}   stackId={b.stackId} fill={b.palette.setup}    name={`${b.name} Setup`} />)}
                          {groupedMCT.bars.map(b => <Bar key={b.prefix+'run'}     dataKey={b.prefix+'run'}     stackId={b.stackId} fill={b.palette.run}      name={`${b.name} Run`} radius={[2,2,0,0]} />)}
                        </BarChart>
                      ) : (
                        <BarChart data={productChartData} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                          <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: `MCT (${model.general.mct_time_unit})`, angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                          <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                          <Bar dataKey="lotWait" stackId="a" fill={chartColors.lotWait} name="Wait for Lot" />
                          <Bar dataKey="queue" stackId="a" fill={chartColors.queue} name="Wait for Equipment" />
                          <Bar dataKey="waitLabor" stackId="a" fill={chartColors.waitLabor} name="Wait for Labor" />
                          <Bar dataKey="setup" stackId="a" fill={chartColors.setup} name="Setup" />
                          <Bar dataKey="run" stackId="a" fill={chartColors.run} name="Run" radius={[2,2,0,0]} />
                        </BarChart>
                      )}
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </>
            )}
            {productsSubTab === 'results-table' && (
              <>
                {isUtilOnly && (
                  <UtilOnlyBanner message="Production counts from Calc. Util Only. MCT and WIP are zero until you run Full Calculate." />
                )}
                <ProductResultsTable results={results!} model={model} displayScenarioResults={displayScenarioResults} isUtilOnly={isUtilOnly} />
              </>
            )}
            {productsSubTab === 'production-chart' && <ProductionChart results={results!} model={model} isMultiScenario={isMultiScenario} chartScenarios={chartScenarios} />}
            {productsSubTab === 'wip-chart' && (
              <>
                {isUtilOnly && <UtilOnlyBanner />}
                <Card>
                  <CardHeader><CardTitle className="text-base">Product WIP (Work In Progress)</CardTitle></CardHeader>
                  <CardContent className="relative">
                    <ChartScenarioLabel />
                    <ResponsiveContainer width="100%" height={300}>
                      {isMultiScenario && groupedWIP ? (
                        <BarChart data={groupedWIP.data} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                          <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: 'WIP Units', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                          <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
                          {groupedWIP.bars.map(b => <Bar key={b.prefix+'wip'} dataKey={b.prefix+'wip'} fill={b.palette.single} name={`${b.name} WIP`} radius={[2,2,0,0]} />)}
                        </BarChart>
                      ) : (
                        <BarChart data={results?.products.map(p => ({ name: p.name, wip: p.wip })) || []} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
                          <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: 'WIP Units', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                          <Tooltip content={<RechartsTooltipWithTotal />} />
                          <Bar dataKey="wip" fill={chartColors.setup} name="WIP" radius={[2,2,0,0]} />
                        </BarChart>
                      )}
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </>
            )}
            {productsSubTab === 'oper-details' && isVisible('oper_details', userLevel) && (
              <>
                {isUtilOnly && <UtilOnlyBanner />}
                <ProductOperDetails model={model} results={results!} />
              </>
            )}
          </div>
        ))}

        {/* ── IBOM Tab ── */}
        {activeTab === 'ibom' && (!hasRun ? <NoResultsPlaceholder /> : (
          <>
            <ScenarioContextBar />
            <IBOMTabContent model={model} results={results!} basecaseResults={basecaseResults}
              isRunning={isRunning} isUtilOnly={isUtilOnly}
              ibomSubTab={ibomSubTab} setIbomSubTab={setIbomSubTab}
            />
          </>
        ))}

        {/* Run Log */}
        {runLog.length > 0 && (
          <Card className="mt-4">
            <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /> Recent Runs</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="text-xs">Time</TableHead>
                  <TableHead className="text-xs">Mode</TableHead>
                  <TableHead className="text-xs">Scenario</TableHead>
                  <TableHead className="text-xs text-right">Duration</TableHead>
                  <TableHead className="text-xs">Status</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {runLog.map(entry => (
                    <TableRow key={entry.id}>
                      <TableCell className="text-xs font-mono">{new Date(entry.timestamp).toLocaleTimeString()}</TableCell>
                      <TableCell className="text-xs capitalize">{entry.mode === 'full' ? 'Full Calculate' : entry.mode === 'verify' ? 'Verify Data' : 'Util Only'}</TableCell>
                      <TableCell className="text-xs">{entry.scenarioName}</TableCell>
                      <TableCell className="text-xs text-right font-mono">{entry.durationMs < 1000 ? `${entry.durationMs}ms` : `${(entry.durationMs/1000).toFixed(1)}s`}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`text-[10px] ${entry.status === 'success' ? 'border-success/40 text-success' : entry.status === 'warning' ? 'border-warning/40 text-warning' : 'border-destructive/40 text-destructive'}`}>
                          {entry.status === 'success' ? <CheckCircle className="h-2.5 w-2.5 mr-0.5" /> : entry.status === 'warning' ? <AlertTriangle className="h-2.5 w-2.5 mr-0.5" /> : <XCircle className="h-2.5 w-2.5 mr-0.5" />}
                          {entry.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>

      {/* ── Max Throughput + Lot Size Range Modal ── */}
      <Dialog open={mtModalOpen} onOpenChange={setMtModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Max. Throughput + Lot Size Range</DialogTitle>
            <DialogDescription>Find max production or sweep lot sizes for a product.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Choose Product</Label>
              <Select value={mtModalProduct} onValueChange={setMtModalProduct}>
                <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
                <SelectContent>{model?.products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">What-if Name</Label>
              <Input value={mtModalName} onChange={e => setMtModalName(e.target.value)} placeholder={mtModalMode === 'max_throughput' ? 'Max Throughput' : 'Lot Size Range'} />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Choose Mode</Label>
              <RadioGroup value={mtModalMode} onValueChange={(v) => setMtModalMode(v as any)}>
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="max_throughput" id="mt-mode-max" className="mt-0.5" />
                  <Label htmlFor="mt-mode-max" className="text-sm font-normal cursor-pointer">
                    <span className="font-medium">Maximise Production</span>
                    <span className="block text-xs text-muted-foreground">Finds the maximum possible production quantity given current constraints.</span>
                  </Label>
                </div>
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="lot_size_range" id="mt-mode-ls" className="mt-0.5" />
                  <Label htmlFor="mt-mode-ls" className="text-sm font-normal cursor-pointer">
                    <span className="font-medium">Run a Range of Lot Sizes</span>
                    <span className="block text-xs text-muted-foreground">Runs a series of calculations across a range of lot sizes.</span>
                  </Label>
                </div>
              </RadioGroup>
              {mtModalMode === 'lot_size_range' && (
                <div className="ml-6 mt-2 space-y-3 p-3 bg-muted/40 rounded-md border border-border">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div className="space-y-1"><Label className="text-xs">From lot size</Label><NonNegativeNumericInput value={mtModalLsFrom} onChange={(v) => setMtModalLsFrom(v)} /></div>
                    <div className="space-y-1"><Label className="text-xs">To lot size</Label><NonNegativeNumericInput value={mtModalLsTo} onChange={(v) => setMtModalLsTo(v)} /></div>
                    <div className="space-y-1"><Label className="text-xs">Step size</Label><NonNegativeNumericInput value={mtModalLsStep} onChange={(v) => setMtModalLsStep(v)} /></div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Will run lot sizes: {(() => { const s: number[] = []; for (let x = mtModalLsFrom; x <= mtModalLsTo && s.length < 5; x += mtModalLsStep) s.push(x); return s.join(', ') + (mtModalLsTo > (mtModalLsFrom + mtModalLsStep * 4) ? '…' : '') + ' (one What-if per lot size)'; })()}
                  </p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setMtModalOpen(false)}>Cancel</Button>
            <Button disabled={!mtModalProduct || advRunning} onClick={async () => {
              setMtModalOpen(false);
              if (!model) return;
              const product = model.products.find(p => p.id === mtModalProduct);
              if (!product) return;
              if (mtModalMode === 'max_throughput') {
                setAdvRunning(true);
                let demand = product.demand > 0 ? product.demand : 100;
                let lastValidDemand = demand, limitingResource = '';
                const step = Math.max(1, Math.round(demand * 0.1));
                let iterations = 0;
                while (iterations < 200) {
                  iterations++;
                  setAdvProgress({ current: iterations, total: 200, label: `Testing demand: ${Math.round(demand)}` });
                  const r = calculate({ ...model, products: model.products.map(p => p.id === mtModalProduct ? { ...p, demand } : p) });
                  if (r.overLimitResources.length > 0) {
                    limitingResource = r.overLimitResources[0];
                    let lo = lastValidDemand, hi = demand;
                    for (let i = 0; i < 20; i++) {
                      const mid = Math.round((lo + hi) / 2);
                      const tr = calculate({ ...model, products: model.products.map(p => p.id === mtModalProduct ? { ...p, demand: mid } : p) });
                      if (tr.overLimitResources.length > 0) { hi = mid; limitingResource = tr.overLimitResources[0]; } else { lo = mid; lastValidDemand = mid; }
                      if (hi - lo <= 1) break;
                    }
                    break;
                  }
                  lastValidDemand = demand; demand += step;
                  await new Promise(r => setTimeout(r, 0));
                }
                const name = mtModalName || `Max Throughput — ${product.name}`;
                const scenarioId = await createScenario(model.id, name);
                useScenarioStore.getState().applyScenarioChange(scenarioId, 'Product', mtModalProduct, product.name, 'demand', 'Demand', lastValidDemand);
                const scenario = useScenarioStore.getState().scenarios.find(s => s.id === scenarioId);
                if (scenario) { const r = calculate(model, scenario); setStoreResults(scenarioId, r); useScenarioStore.getState().markCalculated(scenarioId); scenarioDb.saveResults(scenarioId, r); }
                setMtResult({ demand: lastValidDemand, limitingResource });
                setAdvProgress(null); setAdvRunning(false);
                toast.success(`Max throughput for ${product.name}: ${lastValidDemand} units`);
              } else {
                setAdvRunning(true);
                const steps: number[] = [];
                for (let ls = mtModalLsFrom; ls <= mtModalLsTo; ls += mtModalLsStep) steps.push(ls);
                for (let i = 0; i < steps.length; i++) {
                  setAdvProgress({ current: i + 1, total: steps.length, label: `Lot size: ${steps[i]}` });
                  const testModel = { ...model, products: model.products.map(p => p.id === mtModalProduct ? { ...p, lot_size: steps[i] } : p) };
                  const r = calculate(testModel);
                  const scName = `${mtModalName || product.name} — Lot ${steps[i]}`;
                  const scenarioId = await createScenario(model.id, scName);
                  useScenarioStore.getState().applyScenarioChange(scenarioId, 'Product', mtModalProduct, product.name, 'lot_size', 'Lot Size', steps[i]);
                  const sc = useScenarioStore.getState().scenarios.find(s => s.id === scenarioId);
                  if (sc) { setStoreResults(scenarioId, r); useScenarioStore.getState().markCalculated(scenarioId); scenarioDb.saveResults(scenarioId, r); }
                  await new Promise(r => setTimeout(r, 0));
                }
                setAdvProgress(null); setAdvRunning(false);
                toast.success(`Created ${steps.length} lot size scenarios for ${product.name}`);
              }
            }}>Run</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Optimise Lot Sizes Modal ── */}
      <Dialog open={olModalOpen} onOpenChange={setOlModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Optimise Lot Sizes and Transfer Batches</DialogTitle>
            <DialogDescription>MPX will iteratively adjust lot sizes and transfer batches to minimise weighted WIP.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">What-if Name</Label>
              <Input value={olName} onChange={e => setOlName(e.target.value)} placeholder="Optimised Lot Sizes" />
            </div>
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 border border-border rounded-md overflow-hidden">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="text-xs">Product Name</TableHead>
                    <TableHead className="text-xs text-right w-28">Total Unit Value</TableHead>
                    <TableHead className="text-xs text-center w-24">Opt. Lot Size</TableHead>
                    <TableHead className="text-xs text-center w-24">Opt. T-Batch</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {model?.products.map(p => (
                      <TableRow key={p.id}>
                        <TableCell className="text-sm py-1.5">{p.name}</TableCell>
                        <TableCell className="py-1.5"><NonNegativeNumericInput allowDecimal className="h-7 text-xs text-right w-24 ml-auto" value={olUnitValues[p.id] ?? 1} onChange={(v) => setOlUnitValues(prev => ({ ...prev, [p.id]: v }))} /></TableCell>
                        <TableCell className="text-center py-1.5"><Checkbox checked={olOptLot.has(p.id)} onCheckedChange={checked => { setOlOptLot(prev => { const n = new Set(prev); if (checked) n.add(p.id); else n.delete(p.id); return n; }); }} /></TableCell>
                        <TableCell className="text-center py-1.5"><Checkbox checked={olOptTb.has(p.id)} onCheckedChange={checked => { setOlOptTb(prev => { const n = new Set(prev); if (checked) n.add(p.id); else n.delete(p.id); return n; }); }} /></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <div className="flex flex-col gap-2 shrink-0 w-full lg:w-44">
                <Button size="sm" variant="outline" className="text-xs justify-start" onClick={() => setOlOptLot(new Set(model?.products.map(p => p.id) || []))}>Select All Lot Sizes</Button>
                <Button size="sm" variant="outline" className="text-xs justify-start" onClick={() => setOlOptLot(new Set())}>Deselect All Lot Sizes</Button>
                <Button size="sm" variant="outline" className="text-xs justify-start mt-2" onClick={() => setOlOptTb(new Set(model?.products.map(p => p.id) || []))}>Select All Transfer Batches</Button>
                <Button size="sm" variant="outline" className="text-xs justify-start" onClick={() => setOlOptTb(new Set())}>Deselect All Transfer Batches</Button>
              </div>
            </div>
            <div className="flex gap-6 text-sm">
              <div><span className="text-muted-foreground">Initial WIP Total Unit Value:</span> <span className="font-mono font-medium">{olInitialWip != null ? olInitialWip.toLocaleString() : '—'}</span></div>
              <div><span className="text-muted-foreground">Current WIP Total Unit Value:</span> <span className="font-mono font-medium">{olCurrentWip != null ? olCurrentWip.toLocaleString() : '—'}</span></div>
            </div>
            <p className="text-xs text-muted-foreground">Results will be real numbers. Round up to whole numbers when applying to your model. The function is flat near the optimum so nearby values give similar results.</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOlModalOpen(false)}>Cancel</Button>
            <Button disabled={advRunning || (olOptLot.size === 0 && olOptTb.size === 0)} onClick={async () => {
              setOlModalOpen(false);
              if (!model) return;
              setAdvRunning(true);
              const selectedIds = new Set([...olOptLot, ...olOptTb]);
              const selectedProducts = model.products.filter(p => selectedIds.has(p.id));
              if (selectedProducts.length === 0) { setAdvRunning(false); return; }
              const baseCalc = calculate(model);
              const weightedWip = (r: CalcResults) => r.products.reduce((s, pr) => s + pr.wip * (olUnitValues[pr.id] || 1), 0);
              let bestWip = weightedWip(baseCalc);
              let bestLots: Record<string,number> = {};
              let bestTBatches: Record<string,number> = {};
              model.products.forEach(p => { bestLots[p.id] = p.lot_size; bestTBatches[p.id] = p.tbatch_size; });
              for (let iter = 0; iter < 60; iter++) {
                setAdvProgress({ current: iter+1, total: 60, label: `Weighted WIP: ${Math.round(bestWip)} (iter ${iter+1})` });
                setOlCurrentWip(Math.round(bestWip * 100) / 100);
                let improved = false;
                for (const p of selectedProducts) {
                  if (olOptLot.has(p.id)) {
                    for (const delta of [-Math.max(1, Math.round(bestLots[p.id]*0.1)), Math.max(1, Math.round(bestLots[p.id]*0.1))]) {
                      const newLot = Math.max(1, bestLots[p.id] + delta);
                      if (newLot === bestLots[p.id]) continue;
                      const tm = { ...model, products: model.products.map(pp => ({ ...pp, lot_size: pp.id===p.id ? newLot : (bestLots[pp.id]??pp.lot_size), tbatch_size: bestTBatches[pp.id]??pp.tbatch_size })) };
                      const r = calculate(tm); const w = weightedWip(r);
                      if (w < bestWip && r.overLimitResources.length === 0) { bestLots[p.id] = newLot; bestWip = w; improved = true; }
                    }
                  }
                  if (olOptTb.has(p.id)) {
                    for (const delta of [-Math.max(1, Math.round(Math.abs(bestTBatches[p.id])*0.15)), Math.max(1, Math.round(Math.abs(bestTBatches[p.id])*0.15))]) {
                      const newTb = Math.max(1, bestTBatches[p.id] + delta);
                      if (newTb === bestTBatches[p.id]) continue;
                      const tm = { ...model, products: model.products.map(pp => ({ ...pp, lot_size: bestLots[pp.id]??pp.lot_size, tbatch_size: pp.id===p.id ? newTb : (bestTBatches[pp.id]??pp.tbatch_size) })) };
                      const r = calculate(tm); const w = weightedWip(r);
                      if (w < bestWip && r.overLimitResources.length === 0) { bestTBatches[p.id] = newTb; bestWip = w; improved = true; }
                    }
                  }
                }
                if (!improved) break;
                await new Promise(r => setTimeout(r, 0));
              }
              const scenarioId = await createScenario(model.id, olName || 'Optimised Lot Sizes');
              for (const p of selectedProducts) {
                if (olOptLot.has(p.id) && bestLots[p.id] !== p.lot_size) useScenarioStore.getState().applyScenarioChange(scenarioId, 'Product', p.id, p.name, 'lot_size', 'Lot Size', bestLots[p.id]);
                if (olOptTb.has(p.id) && bestTBatches[p.id] !== p.tbatch_size) useScenarioStore.getState().applyScenarioChange(scenarioId, 'Product', p.id, p.name, 'tbatch_size', 'Transfer Batch Size', bestTBatches[p.id]);
              }
              const scenario = useScenarioStore.getState().scenarios.find(s => s.id === scenarioId);
              if (scenario) { const r = calculate(model, scenario); setStoreResults(scenarioId, r); useScenarioStore.getState().markCalculated(scenarioId); scenarioDb.saveResults(scenarioId, r); }
              setOlCurrentWip(Math.round(bestWip * 100) / 100); setAdvProgress(null); setAdvRunning(false);
              const reduction = olInitialWip ? Math.round((1 - bestWip / olInitialWip) * 100) : 0;
              toast.success(`Optimisation complete — weighted WIP reduced by ${reduction}%`);
            }}>Run Optimisation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─── Util-Only Banner ─── */
function UtilOnlyBanner({ message }: { message?: string }) {
  return (
    <div className="flex items-center gap-2 p-3 mb-4 bg-warning/10 border border-warning/30 rounded-md">
      <AlertTriangle className="h-4 w-4 text-warning shrink-0" />
      <span className="text-sm text-warning font-medium">{message || 'WIP and MCT results require Full Calculate. These results show utilisation data only.'}</span>
    </div>
  );
}

/* ─── IBOM Tab Content ─── */
function IBOMTabContent({ model, results, basecaseResults, isRunning, isUtilOnly, ibomSubTab, setIbomSubTab }: {
  model: Model; results: CalcResults; basecaseResults: CalcResults | undefined; isRunning: boolean; isUtilOnly: boolean;
  ibomSubTab: string; setIbomSubTab: (t: string) => void;
}) {
  const allScenarios = useScenarioStore(s => s.scenarios);
  const modelScenarios = allScenarios.filter(s => s.modelId === model.id);
  const { getResults } = useResultsStore();

  const finalAssemblies = useMemo(() => {
    const parentIds = new Set(model.ibom.map(e => e.parent_product_id));
    const componentIds = new Set(model.ibom.map(e => e.component_product_id));
    const topLevel = model.products.filter(p => parentIds.has(p.id) && !componentIds.has(p.id));
    return topLevel.length > 0 ? topLevel : model.products.filter(p => parentIds.has(p.id));
  }, [model]);

  const [selectedProductId, setSelectedProductId] = useState(() => finalAssemblies[0]?.id || '');
  const [scenarioId, setScenarioId] = useState('basecase');

  const ibomResults = getResults(scenarioId) || results;
  const scenario = allScenarios.find(s => s.id === scenarioId);
  const scenarioLabel = scenarioId === 'basecase' ? 'Basecase results' : `${scenario?.name || 'What-if'} results`;
  const mctUnit = model.general.mct_time_unit.toLowerCase() + 's';
  const runScenarios = modelScenarios.filter(s => getResults(s.id));

  if (model.ibom.length === 0 || finalAssemblies.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Network className="h-10 w-10 text-muted-foreground/30 mb-3" />
        <p className="text-base font-medium text-muted-foreground mb-1">No IBOM structure defined</p>
        <p className="text-sm text-muted-foreground/70">Go to Input → IBOM to add component relationships between products.</p>
      </div>
    );
  }

  const hasChildren = model.ibom.some(e => e.parent_product_id === selectedProductId);
  const tree = hasChildren ? buildNodeTree(model, ibomResults, selectedProductId, 0, new Set()) : null;
  const poles = tree ? buildPoles(tree) : [];

  return (
    <div className="flex flex-col h-full">
      <div className="flex h-8 items-center gap-0 border-b border-border/50 -mx-3 md:-mx-4 lg:-mx-6 px-3 md:px-4 lg:px-6 mb-0 shrink-0 overflow-x-auto">
        {([{ key: 'tree-chart', label: 'Tree Chart' }, { key: 'tree-table', label: 'Tree Table' }, { key: 'poles-chart', label: 'Poles Chart' }, { key: 'poles-table', label: 'Poles Table' }] as const).map(st => (
          <button key={st.key} onClick={() => setIbomSubTab(st.key)}
            className={`h-8 px-4 text-[13px] relative transition-colors ${ibomSubTab === st.key ? 'text-foreground font-medium' : 'text-muted-foreground hover:text-foreground'}`}>
            {st.label}
            {ibomSubTab === st.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary/60" />}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2 md:gap-3 py-3 -mx-3 md:-mx-4 lg:-mx-6 px-3 md:px-4 lg:px-6 border-b border-border/30 mb-4">
        <Select value={selectedProductId} onValueChange={setSelectedProductId}>
          <SelectTrigger className="w-full sm:w-56 md:w-48 h-8 text-xs"><SelectValue placeholder="Select assembly..." /></SelectTrigger>
          <SelectContent>{finalAssemblies.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
        </Select>
        <div className="flex-1" />
        <Select value={scenarioId} onValueChange={setScenarioId}>
          <SelectTrigger className="w-full sm:w-48 md:w-44 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="basecase">Basecase</SelectItem>
            {runScenarios.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex-1" />
        <span className="text-sm font-medium text-primary whitespace-nowrap">{scenarioLabel}</span>
      </div>
      {isUtilOnly && <UtilOnlyBanner message="IBOM MCT results require Full Calculate." />}
      {!tree ? (
        <div className="py-12 text-center"><p className="text-sm text-muted-foreground">This product has no components. Select a product with sub-assemblies to view the IBOM tree.</p></div>
      ) : (
        <>
          {ibomSubTab === 'tree-chart'  && (<><TreeChart  model={model} results={ibomResults} tree={tree} mctUnit={mctUnit} /><MCTLegend /></>)}
          {ibomSubTab === 'tree-table'  && <TreeTable  model={model} results={ibomResults} tree={tree} mctUnit={mctUnit} />}
          {ibomSubTab === 'poles-chart' && (<><PolesChart model={model} poles={poles} mctUnit={mctUnit} /><MCTLegend /></>)}
          {ibomSubTab === 'poles-table' && <PolesTable model={model} poles={poles} mctUnit={mctUnit} />}
        </>
      )}
    </div>
  );
}

/* ─── Product Results Table ─── */
function ProductResultsTable({ results, model, displayScenarioResults, isUtilOnly = false }: {
  results: CalcResults; model: any;
  displayScenarioResults: { id: string; scenario: any; results: CalcResults }[];
  isUtilOnly?: boolean;
}) {
  const { sorted, sort, handleSort } = useSortableTable(results.products, 'mct', 'desc');
  const hasScenarios = displayScenarioResults.length > 0;
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Product Results Table</CardTitle></CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          <TableHeader><TableRow>
            <SortHead label="Product" sortKey="name" current={sort} onSort={handleSort} align="left" />
            <SortHead label="Demand" sortKey="demand" current={sort} onSort={handleSort} />
            <SortHead label={PRODUCT_METRIC_LABELS.goodMade} sortKey="goodMade" current={sort} onSort={handleSort} />
            <SortHead label={PRODUCT_METRIC_LABELS.goodShipped} sortKey="goodShipped" current={sort} onSort={handleSort} />
            <SortHead label={PRODUCT_METRIC_LABELS.started} sortKey="started" current={sort} onSort={handleSort} />
            <SortHead label="Scrap" sortKey="scrap" current={sort} onSort={handleSort} />
            <SortHead label="WIP" sortKey="wip" current={sort} onSort={handleSort} />
            <SortHead label="MCT" sortKey="mct" current={sort} onSort={handleSort} />
            {hasScenarios && displayScenarioResults.map(sr => (
              <React.Fragment key={sr.id}>
                <TableHead className="font-mono text-xs text-right">{sr.scenario.name} WIP</TableHead>
                <TableHead className="font-mono text-xs text-right">{sr.scenario.name} MCT</TableHead>
              </React.Fragment>
            ))}
          </TableRow></TableHeader>
          <TableBody>
            {sorted.map((row: any) => (
              <TableRow key={row.id}>
                <TableCell className="font-mono font-medium">{row.name}</TableCell>
                <TableCell className="font-mono text-right">{row.demand?.toLocaleString()}</TableCell>
                <TableCell className="font-mono text-right">{row.goodMade.toLocaleString()}</TableCell>
                <TableCell className="font-mono text-right">{row.goodShipped.toLocaleString()}</TableCell>
                <TableCell className="font-mono text-right">{row.started.toLocaleString()}</TableCell>
                <TableCell className="font-mono text-right">{row.scrap > 0 ? row.scrap.toLocaleString() : '—'}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(isUtilOnly ? 0 : row.wip, 3)}</TableCell>
                <TableCell className="font-mono text-right font-medium">{fmtRound(isUtilOnly ? 0 : row.mct, 3)}</TableCell>
                {hasScenarios && displayScenarioResults.map(sr => {
                  const sp = sr.results.products.find((p: any) => p.id === row.id);
                  return (
                    <React.Fragment key={sr.id}>
                      <TableCell className="font-mono text-right text-xs">{sp ? fmtRound(isUtilOnly ? 0 : sp.wip, 3) : '—'}</TableCell>
                      <TableCell className={`font-mono text-right text-xs ${!isUtilOnly && sp && sp.mct < row.mct ? 'text-success' : !isUtilOnly && sp && sp.mct > row.mct ? 'text-destructive' : ''}`}>
                        {sp ? fmtRound(isUtilOnly ? 0 : sp.mct, 3) : '—'}
                      </TableCell>
                    </React.Fragment>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

/* ─── Product Oper Details ─── */
function ProductOperDetails({ model, results }: { model: Model; results: CalcResults }) {
  const [selectedId, setSelectedId] = useState('');
  const [showTimeUnits, setShowTimeUnits] = useState(false);
  const g = model.general;

  // BUG-E/F/D FIX: use shared corrected metrics builder
  const allMetrics = useMemo(() => buildOperMetrics(model, results), [model, results]);

  const fmtVal = (pct: number, time: number) => showTimeUnits ? fmtRound(time, 2) : fmtRound(pct, 2);
  const unitSuffix = showTimeUnits ? ` (${g.ops_time_unit})` : ' %';

  const prodOps = useMemo(() => allMetrics.filter((m: any) => m.productId === selectedId), [allMetrics, selectedId]);
  const prodSort = useSortableTable(prodOps, 'opNumber', 'asc');
  const prod = model.products.find((p: any) => p.id === selectedId);

  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Oper Details — By Product</CardTitle></CardHeader>
      <CardContent>
        <div className="flex items-center gap-3 mb-4">
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="w-full sm:w-64 md:w-56 h-8 text-xs"><SelectValue placeholder="Select product…" /></SelectTrigger>
            <SelectContent>{model.products.map((p: any) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
          </Select>
          <Button variant={showTimeUnits ? 'secondary' : 'outline'} size="sm" className="text-xs gap-1 h-7" onClick={() => setShowTimeUnits(!showTimeUnits)}>
            <Clock className="h-3 w-3" />{showTimeUnits ? `Time (${g.ops_time_unit})` : '% Time'}
          </Button>
        </div>
        {!prod ? (
          <p className="text-sm text-muted-foreground text-center py-8">Select a product to view operation details.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <SortHead label="Operation"       sortKey="opName"      current={prodSort.sort} onSort={prodSort.handleSort} align="left" />
                <SortHead label="Equipment"       sortKey="equipName"   current={prodSort.sort} onSort={prodSort.handleSort} align="left" />
                <SortHead label="Labor"           sortKey="laborName"   current={prodSort.sort} onSort={prodSort.handleSort} align="left" />
                <SortHead label="% Assign"        sortKey="pctAssigned" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label={`Eq Setup${unitSuffix}`}   sortKey="eqSetupUtil"  current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label={`Eq Run${unitSuffix}`}     sortKey="eqRunUtil"    current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label={`Repair${unitSuffix}`}     sortKey="repairUtil"   current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label={`Lab Setup${unitSuffix}`}  sortKey="labSetupUtil" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label={`Lab Run${unitSuffix}`}    sortKey="labRunUtil"   current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Time waiting for equipment" sortKey="timeWaitingEquipment" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Time waiting for labor" sortKey="timeWaitingLabor" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Time in setup" sortKey="timeInSetup" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Time in run" sortKey="timeInRun" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Time waiting for rest of lot" sortKey="timeWaitingRestOfLot" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Visits for 1 good piece" sortKey="visitsPerGoodPiece" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="no. of setups" sortKey="noOfSetups" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="Avg lot size" sortKey="avgLotSize" current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="WIP"             sortKey="wip"         current={prodSort.sort} onSort={prodSort.handleSort} />
                <SortHead label="MCT at Op"       sortKey="mctAtOp"     current={prodSort.sort} onSort={prodSort.handleSort} />
              </TableRow></TableHeader>
              <TableBody>
                {prodSort.sorted.map((m: any) => (
                  <TableRow key={m.opId}>
                    <TableCell className="font-mono text-xs font-medium">{m.opName}</TableCell>
                    <TableCell className="font-mono text-xs">{m.equipName}</TableCell>
                    <TableCell className="font-mono text-xs">{m.laborName}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.pctAssigned, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.eqSetupUtil,  m.eqSetupTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.eqRunUtil,    m.eqRunTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.repairUtil, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.labSetupUtil, m.labSetupTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.labRunUtil,   m.labRunTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingEquipment, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingLabor, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeInSetup, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeInRun, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingRestOfLot, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.visitsPerGoodPiece, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.noOfSetups, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.avgLotSize, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.wip, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.mctAtOp, 2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ─── Equipment Oper Details ─── */
function useRunDescriptionLabel(): string {
  const selectedRunScenarioId = useResultsStore((s) => s.selectedRunScenarioId);
  const scenarios = useScenarioStore((s) => s.scenarios);
  return useMemo(() => {
    if (!selectedRunScenarioId || selectedRunScenarioId === 'basecase') return 'Basecase';
    return scenarios.find((s) => s.id === selectedRunScenarioId)?.name ?? 'Basecase';
  }, [selectedRunScenarioId, scenarios]);
}

function EquipOperDetails({ model, results }: { model: Model; results: CalcResults }) {
  const [selectedId, setSelectedId] = useState('');
  const [showTimeUnits, setShowTimeUnits] = useState(false);
  const g = model.general;
  const runDescription = useRunDescriptionLabel();

  // BUG-E/F/D FIX: use shared corrected metrics builder
  const allMetrics = useMemo(() => buildOperMetrics(model, results), [model, results]);

  const fmtVal = (pct: number, time: number) => showTimeUnits ? fmtRound(time, 2) : fmtRound(pct, 2);
  const unitSuffix = showTimeUnits ? ` (${g.ops_time_unit})` : ' %';

  const eqOps = useMemo(() => allMetrics.filter((m: any) => m.equipId === selectedId), [allMetrics, selectedId]);
  const eqSort = useSortableTable(eqOps, 'opNumber', 'asc');
  const eq = model.equipment.find(e => e.id === selectedId);

  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Oper Details — By Equipment</CardTitle></CardHeader>
      <CardContent>
        <div className="flex items-center gap-3 mb-4">
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="w-full sm:w-64 md:w-56 h-8 text-xs"><SelectValue placeholder="Select equipment group…" /></SelectTrigger>
            <SelectContent>{model.equipment.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}</SelectContent>
          </Select>
          <Button variant={showTimeUnits ? 'secondary' : 'outline'} size="sm" className="text-xs gap-1 h-7" onClick={() => setShowTimeUnits(!showTimeUnits)}>
            <Clock className="h-3 w-3" />{showTimeUnits ? `Time (${g.ops_time_unit})` : '% Time'}
          </Button>
        </div>
        {!eq ? (
          <p className="text-sm text-muted-foreground text-center py-8">Select an equipment group to view operation details.</p>
        ) : (
          <>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <SortHead label="Product"         sortKey="productName" current={eqSort.sort} onSort={eqSort.handleSort} align="left" />
                <SortHead label="Operation"       sortKey="opName"      current={eqSort.sort} onSort={eqSort.handleSort} align="left" />
                <SortHead label="Op #"            sortKey="opNumber"    current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="% Assign"        sortKey="pctAssigned" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label={`Eq Setup${unitSuffix}`}   sortKey="eqSetupUtil"   current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label={`Eq Run${unitSuffix}`}     sortKey="eqRunUtil"     current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label={`Lab Setup${unitSuffix}`}  sortKey="labSetupUtil"  current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label={`Lab Run${unitSuffix}`}    sortKey="labRunUtil"    current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Time waiting for equipment" sortKey="timeWaitingEquipment" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Time waiting for labor" sortKey="timeWaitingLabor" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Time in setup" sortKey="timeInSetup" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Time in run" sortKey="timeInRun" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Time waiting for rest of lot" sortKey="timeWaitingRestOfLot" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Visits for 1 good piece" sortKey="visitsPerGoodPiece" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="no. of setups" sortKey="noOfSetups" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Avg lot size" sortKey="avgLotSize" current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="WIP"             sortKey="wip"         current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="MCT at Op"       sortKey="mctAtOp"     current={eqSort.sort} onSort={eqSort.handleSort} />
                <SortHead label="Visits/100"      sortKey="visits"      current={eqSort.sort} onSort={eqSort.handleSort} />
              </TableRow></TableHeader>
              <TableBody>
                {eqSort.sorted.map((m: any) => (
                  <TableRow key={m.opId}>
                    <TableCell className="font-mono text-xs">{m.productName}</TableCell>
                    <TableCell className="font-mono text-xs font-medium">{m.opName}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{m.opNumber}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.pctAssigned, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.eqSetupUtil,  m.eqSetupTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.eqRunUtil,    m.eqRunTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.labSetupUtil, m.labSetupTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.labRunUtil,   m.labRunTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingEquipment, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingLabor, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeInSetup, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeInRun, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingRestOfLot, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.visitsPerGoodPiece, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.noOfSetups, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.avgLotSize, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.wip, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.mctAtOp, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.visits, 2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <ProductGroupSummaryTable
            metrics={eqOps}
            model={model}
            description={runDescription}
            showTimeUnits={showTimeUnits}
            timeUnitLabel={g.ops_time_unit}
          />
          </>
        )}
      </CardContent>
    </Card>
  );
}

/* ─── Labor Oper Details ─── */
function LaborOperDetails({ model, results }: { model: Model; results: CalcResults }) {
  const [selectedId, setSelectedId] = useState('');
  const [showTimeUnits, setShowTimeUnits] = useState(false);
  const g = model.general;
  const runDescription = useRunDescriptionLabel();

  // BUG-E/F/D FIX: use shared corrected metrics builder
  const allMetrics = useMemo(() => buildOperMetrics(model, results), [model, results]);

  const fmtVal = (pct: number, time: number) => showTimeUnits ? fmtRound(time, 2) : fmtRound(pct, 2);
  const unitSuffix = showTimeUnits ? ` (${g.ops_time_unit})` : ' %';

  const labOps = useMemo(() => allMetrics.filter((m: any) => m.laborId === selectedId), [allMetrics, selectedId]);
  const labSort = useSortableTable(labOps, 'opNumber', 'asc');
  const lab = model.labor.find(l => l.id === selectedId);

  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Oper Details — By Labor</CardTitle></CardHeader>
      <CardContent>
        <div className="flex items-center gap-3 mb-4">
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="w-full sm:w-64 md:w-56 h-8 text-xs"><SelectValue placeholder="Select labor group…" /></SelectTrigger>
            <SelectContent>{model.labor.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent>
          </Select>
          <Button variant={showTimeUnits ? 'secondary' : 'outline'} size="sm" className="text-xs gap-1 h-7" onClick={() => setShowTimeUnits(!showTimeUnits)}>
            <Clock className="h-3 w-3" />{showTimeUnits ? `Time (${g.ops_time_unit})` : '% Time'}
          </Button>
        </div>
        {!lab ? (
          <p className="text-sm text-muted-foreground text-center py-8">Select a labor group to view operation details.</p>
        ) : (
          <>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <SortHead label="Product"         sortKey="productName" current={labSort.sort} onSort={labSort.handleSort} align="left" />
                <SortHead label="Operation"       sortKey="opName"      current={labSort.sort} onSort={labSort.handleSort} align="left" />
                <SortHead label="Equipment"       sortKey="equipName"   current={labSort.sort} onSort={labSort.handleSort} align="left" />
                <SortHead label="% Assign"        sortKey="pctAssigned" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label={`Lab Setup${unitSuffix}`} sortKey="labSetupUtil" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label={`Lab Run${unitSuffix}`}   sortKey="labRunUtil"   current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label={`Eq Setup${unitSuffix}`}  sortKey="eqSetupUtil"  current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label={`Eq Run${unitSuffix}`}    sortKey="eqRunUtil"    current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label={`Wait Labor${unitSuffix}`} sortKey="waitLaborUtil" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Time waiting for equipment" sortKey="timeWaitingEquipment" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Time waiting for labor" sortKey="timeWaitingLabor" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Time in setup" sortKey="timeInSetup" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Time in run" sortKey="timeInRun" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Time waiting for rest of lot" sortKey="timeWaitingRestOfLot" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Visits for 1 good piece" sortKey="visitsPerGoodPiece" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="no. of setups" sortKey="noOfSetups" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="Avg lot size" sortKey="avgLotSize" current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="WIP"             sortKey="wip"         current={labSort.sort} onSort={labSort.handleSort} />
                <SortHead label="MCT at Op"       sortKey="mctAtOp"     current={labSort.sort} onSort={labSort.handleSort} />
              </TableRow></TableHeader>
              <TableBody>
                {labSort.sorted.map((m: any) => (
                  <TableRow key={m.opId}>
                    <TableCell className="font-mono text-xs">{m.productName}</TableCell>
                    <TableCell className="font-mono text-xs font-medium">{m.opName}</TableCell>
                    <TableCell className="font-mono text-xs">{m.equipName}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.pctAssigned, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.labSetupUtil, m.labSetupTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.labRunUtil,   m.labRunTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.eqSetupUtil,  m.eqSetupTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtVal(m.eqRunUtil,    m.eqRunTime)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.waitLaborUtil, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingEquipment, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingLabor, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeInSetup, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeInRun, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.timeWaitingRestOfLot, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.visitsPerGoodPiece, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.noOfSetups, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.avgLotSize, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.wip, 2)}</TableCell>
                    <TableCell className="font-mono text-xs text-right">{fmtRound(m.mctAtOp, 2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <ProductGroupSummaryTable
            metrics={labOps}
            model={model}
            description={runDescription}
            showTimeUnits={showTimeUnits}
            timeUnitLabel={g.ops_time_unit}
          />
          </>
        )}
      </CardContent>
    </Card>
  );
}

/* ─── Shared sub-components ─── */
function NoResultsPlaceholder() {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <BarChart3 className="h-10 w-10 text-muted-foreground/30 mb-3" />
      <p className="text-base font-medium text-muted-foreground mb-1">No results yet</p>
      <p className="text-sm text-muted-foreground/70">Run Full Calculate to see results.</p>
    </div>
  );
}

function QuickStatCard({ label, value, metric }: { label: string; value: string; metric: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4 md:p-5 shadow-sm min-w-0">
      <p className="text-lg lg:text-xl font-bold text-slate-900 leading-tight truncate" title={value}>
        {value}
      </p>
      {metric && (
        <p className="text-sm text-slate-600 mt-1 truncate" title={metric}>
          {metric}
        </p>
      )}
      <p className="text-xs text-slate-500 mt-2 truncate" title={label}>
        {label}
      </p>
    </div>
  );
}

function NormalSummary({ results, model, scenarioResults, isUtilOnly = false }: {
  results: CalcResults; model: any;
  scenarioResults: { id: string; scenario: any; results: CalcResults }[];
  isUtilOnly?: boolean;
}) {
  const hasScenarios = scenarioResults.length > 0;
  const showWip = (wip: number) => fmtRound(isUtilOnly ? 0 : wip, 2);
  const showMct = (mct: number) => fmtRound(isUtilOnly ? 0 : mct, 2);
  const groups = useMemo(() => {
    const map = new Map<string, ProductResult[]>();
    results.products.forEach(pr => {
      const prod = model.products.find((p: any) => p.id === pr.id);
      const group = prod?.dept_code || '';
      if (!map.has(group)) map.set(group, []);
      map.get(group)!.push(pr);
    });
    return map;
  }, [results, model]);
  const hasGroups = [...groups.keys()].some(k => k !== '');

  const renderProductRow = (row: ProductResult) => (
    <TableRow key={row.id}>
      <TableCell className="font-mono font-medium">{row.name}</TableCell>
      <TableCell className="font-mono text-right">{row.goodMade.toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right">{row.goodShipped.toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right">{row.started.toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right">{row.scrap > 0 ? row.scrap.toLocaleString() : '—'}</TableCell>
      <TableCell className="font-mono text-right">{showWip(row.wip)}</TableCell>
      <TableCell className="font-mono text-right font-medium">{showMct(row.mct)}</TableCell>
      {hasScenarios && scenarioResults.map(sr => {
        const sp = sr.results.products.find(p => p.id === row.id);
        const baseMct = isUtilOnly ? 0 : row.mct;
        return (
          <React.Fragment key={sr.id}>
            <TableCell className="font-mono text-right text-xs">{sp ? showWip(sp.wip) : '—'}</TableCell>
            <TableCell className={`font-mono text-right text-xs ${!isUtilOnly && sp && sp.mct < baseMct ? 'text-success' : !isUtilOnly && sp && sp.mct > baseMct ? 'text-destructive' : ''}`}>
              {sp ? showMct(sp.mct) : '—'}
              {!isUtilOnly && sp && sp.mct !== baseMct && <span className="ml-1 text-[10px]">({(sp.mct - baseMct) > 0 ? '+' : ''}{fmtRound(sp.mct - baseMct, 2)})</span>}
            </TableCell>
          </React.Fragment>
        );
      })}
    </TableRow>
  );

  const renderSubtotal = (label: string, products: ProductResult[]) => (
    <TableRow key={`sub-${label}`} className="bg-[#EAEFEF] font-medium">
      <TableCell className="font-mono text-xs">{label} subtotal</TableCell>
      <TableCell className="font-mono text-right text-xs">{products.reduce((s,r) => s+r.goodMade,0).toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right text-xs">{products.reduce((s,r) => s+r.goodShipped,0).toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right text-xs">{products.reduce((s,r) => s+r.started,0).toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right text-xs">{products.reduce((s,r) => s+r.scrap,0).toLocaleString()}</TableCell>
      <TableCell className="font-mono text-right text-xs">{isUtilOnly ? '0.00' : fmtRound(products.reduce((s, r) => s + r.wip, 0), 2)}</TableCell>
      <TableCell className="font-mono text-right text-xs">{isUtilOnly ? '0.00' : `${fmtRound(Math.min(...products.map(p => p.mct)), 2)}–${fmtRound(Math.max(...products.map(p => p.mct)), 2)}`}</TableCell>
      {hasScenarios && scenarioResults.map(sr => <React.Fragment key={sr.id}><TableCell /><TableCell /></React.Fragment>)}
    </TableRow>
  );

  return (
    <Table>
      <TableHeader><TableRow>
        <TableHead className="font-mono text-xs">Product</TableHead>
        <TableHead className="font-mono text-xs text-right">{PRODUCT_METRIC_LABELS.goodMade}</TableHead>
        <TableHead className="font-mono text-xs text-right">{PRODUCT_METRIC_LABELS.goodShipped}</TableHead>
        <TableHead className="font-mono text-xs text-right">{PRODUCT_METRIC_LABELS.started}</TableHead>
        <TableHead className="font-mono text-xs text-right">Scrap</TableHead>
        <TableHead className="font-mono text-xs text-right">WIP</TableHead>
        <TableHead className="font-mono text-xs text-right">MCT ({model.general.mct_time_unit})</TableHead>
        {hasScenarios && scenarioResults.map(sr => (
          <React.Fragment key={sr.id}>
            <TableHead className="font-mono text-xs text-right text-primary">WIP {sr.scenario.name}</TableHead>
            <TableHead className="font-mono text-xs text-right text-primary">MCT {sr.scenario.name}</TableHead>
          </React.Fragment>
        ))}
      </TableRow></TableHeader>
      <TableBody>
        {hasGroups
          ? [...groups.entries()].map(([group, products]) => (
              <React.Fragment key={`grp-${group}`}>{products.map(renderProductRow)}{group && renderSubtotal(group, products)}</React.Fragment>
            ))
          : results.products.map(renderProductRow)}
        <TableRow className="border-t-2 font-medium">
          <TableCell className="font-mono">TOTAL</TableCell>
          <TableCell className="font-mono text-right">{results.products.reduce((s,r) => s+r.goodMade,0).toLocaleString()}</TableCell>
          <TableCell className="font-mono text-right">{results.products.reduce((s,r) => s+r.goodShipped,0).toLocaleString()}</TableCell>
          <TableCell className="font-mono text-right">{results.products.reduce((s,r) => s+r.started,0).toLocaleString()}</TableCell>
          <TableCell className="font-mono text-right">{results.products.reduce((s,r) => s+r.scrap,0).toLocaleString()}</TableCell>
          <TableCell className="font-mono text-right">{isUtilOnly ? '0.00' : fmtRound(results.products.reduce((s, r) => s + r.wip, 0), 2)}</TableCell>
          <TableCell className="font-mono text-right">{isUtilOnly ? '0.00' : '—'}</TableCell>
          {hasScenarios && scenarioResults.map(sr => <React.Fragment key={sr.id}><TableCell /><TableCell /></React.Fragment>)}
        </TableRow>
      </TableBody>
    </Table>
  );
}

function TransposedSummary({ results, model, scenarioResults, isUtilOnly = false }: {
  results: CalcResults; model: any;
  scenarioResults: { id: string; scenario: any; results: CalcResults }[];
  isUtilOnly?: boolean;
}) {
  const fields = [
    { key: 'demand',      label: 'Demand',                fmt: (v: number) => v.toLocaleString() },
    { key: 'lotSize',     label: 'Lot Size',               fmt: (v: number) => v.toString() },
    { key: 'goodMade',    label: PRODUCT_METRIC_LABELS.goodMade,              fmt: (v: number) => v.toLocaleString() },
    { key: 'started',     label: PRODUCT_METRIC_LABELS.started,                fmt: (v: number) => v.toLocaleString() },
    { key: 'scrap',       label: 'Scrap',                  fmt: (v: number) => v > 0 ? v.toLocaleString() : '—' },
    { key: 'wip',         label: 'WIP',                    fmt: (v: number) => fmtRound(isUtilOnly ? 0 : v, 2) },
    { key: 'mct',         label: `MCT (${model.general.mct_time_unit})`, fmt: (v: number) => fmtRound(isUtilOnly ? 0 : v, 2) },
  ];
  return (
    <Table>
      <TableHeader><TableRow>
        <TableHead className="font-mono text-xs">Metric</TableHead>
        {results.products.map(p => <TableHead key={p.id} className="font-mono text-xs text-right">{p.name}</TableHead>)}
      </TableRow></TableHeader>
      <TableBody>
        {fields.map(f => (
          <TableRow key={f.key}>
            <TableCell className="font-mono font-medium text-xs">{f.label}</TableCell>
            {results.products.map(p => <TableCell key={p.id} className="font-mono text-right text-xs">{f.fmt((p as any)[f.key])}</TableCell>)}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

/* ─── Equipment WIP Chart ─── */
function EquipmentWIPChart({ results, model, isMultiScenario, chartScenarios }: {
  results: CalcResults; model: Model; isMultiScenario: boolean; chartScenarios: ScenarioEntry[];
}) {
  const wipData = useMemo(() => {
    return results.equipment
      .map(er => {
        const anyEr: any = er as any;
        const inProcess = asNum(anyEr.wip_process ?? anyEr.wipProcess ?? 0);
        const waiting = asNum(anyEr.wip_queue ?? anyEr.wipQueue ?? 0);
        const total = asNum(anyEr.wip_total ?? anyEr.wipTotal ?? inProcess + waiting);
        return {
          name: er.name,
          inProcess: Math.round(inProcess * 10) / 10,
          waiting: Math.round(waiting * 10) / 10,
          total: Math.round((total) * 10) / 10,
        };
      })
      .filter(e => e.inProcess > 0 || e.waiting > 0);
  }, [results]);

  if (wipData.length === 0) return (
    <Card><CardContent className="py-12 text-center"><BarChart3 className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" /><p className="text-sm text-muted-foreground">Run the model to see Equipment WIP results.</p></CardContent></Card>
  );
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Equipment WIP</CardTitle><CardDescription>Work-in-progress at each equipment group</CardDescription></CardHeader>
      <CardContent className="relative">
        <ChartScenarioLabel />
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={wipData} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
            <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: 'WIP (units)', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
            <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
            <Bar dataKey="inProcess" fill="hsl(270, 50%, 60%)" name="In Process" />
            <Bar dataKey="waiting" fill="hsl(38, 92%, 50%)" name="Waiting" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

/* ─── Labor Equipment Wait Chart ─── */
function LaborWaitChart({ results, model }: { results: CalcResults; model: Model }) {
  const waitData = useMemo(() => {
    return model.labor.map(lab => {
      const equipGroups = model.equipment.filter(eq => eq.labor_group_id === lab.id);
      const laborResult = results.labor.find(l => l.id === lab.id);
      const machinesTendedFallback = equipGroups.reduce((sum, eq) => {
        const er = results.equipment.find(e => e.id === eq.id);
        return sum + (er ? Math.min(1, (er.setupUtil + er.runUtil) / 100) * eq.count : 0);
      }, 0);
      const machinesWaitingFallback = equipGroups.reduce((sum, eq) => {
        const er = results.equipment.find(e => e.id === eq.id);
        return sum + (er ? (er.waitLaborUtil / 100) * eq.count : 0);
      }, 0);
      const anyLabor: any = laborResult as any;
      const machinesTended = asNum(anyLabor?.machinesTended ?? machinesTendedFallback);
      const machinesWaiting = asNum(anyLabor?.machinesWaiting ?? machinesWaitingFallback);
      const avgWaitLaborUtil = asNum(
        anyLabor?.avgWaitLaborUtil ??
        equipGroups.reduce((sum, eq) => { const er = results.equipment.find(e => e.id === eq.id); return sum + (er?.waitLaborUtil || 0); }, 0) / Math.max(1, equipGroups.length),
      );
      return {
        name: lab.name,
        tended: Math.round(machinesTended * 10) / 10,
        waiting: Math.round(machinesWaiting * 10) / 10,
        waitLaborUtil: avgWaitLaborUtil,
        idle: laborResult?.idle || 0,
      };
    }).filter(d => d.tended > 0 || d.waiting > 0 || d.waitLaborUtil > 0);
  }, [results, model]);

  if (waitData.length === 0) return (
    <Card><CardContent className="py-12 text-center"><BarChart3 className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" /><p className="text-sm text-muted-foreground">Run the model to see Equipment Wait results.</p></CardContent></Card>
  );
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Equipment Wait Chart</CardTitle><CardDescription>High 'Waiting' bars indicate a labor shortage — machines are idle waiting for operators.</CardDescription></CardHeader>
      <CardContent className="relative">
        <ChartScenarioLabel />
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={waitData} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
            <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: 'Machines', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
            <Tooltip content={<RechartsTooltipWithTotal />} /><Legend wrapperStyle={{ fontSize: 11 }} />
            <Bar dataKey="tended" fill="hsl(142, 71%, 45%)" name="Avg Machines Tended" />
            <Bar dataKey="waiting" fill="hsl(0, 72%, 51%)" name="Avg Machines Waiting" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

function EquipmentResultsTable({ equipment, utilLimit }: { equipment: EquipmentResult[]; utilLimit: number }) {
  const { sorted, sort, handleSort } = useSortableTable(equipment, 'totalUtil', 'desc');
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Equipment Results Table</CardTitle></CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          <TableHeader><TableRow>
            <SortHead label="Equipment"     sortKey="name"          current={sort} onSort={handleSort} align="left" />
            <SortHead label="Count"         sortKey="count"         current={sort} onSort={handleSort} />
            <SortHead label="Setup %"       sortKey="setupUtil"     current={sort} onSort={handleSort} />
            <SortHead label="Run %"         sortKey="runUtil"       current={sort} onSort={handleSort} />
            <SortHead label="Repair %"      sortKey="repairUtil"    current={sort} onSort={handleSort} />
            <SortHead label="Wait Labor %"  sortKey="waitLaborUtil" current={sort} onSort={handleSort} />
            <SortHead label="Total %"       sortKey="totalUtil"     current={sort} onSort={handleSort} />
            <SortHead label="Idle %"        sortKey="idle"          current={sort} onSort={handleSort} />
            <SortHead label="Labor"         sortKey="laborGroup"    current={sort} onSort={handleSort} align="left" />
          </TableRow></TableHeader>
          <TableBody>
            {sorted.map(eq => (
              <TableRow key={eq.id}>
                <TableCell className="font-mono font-medium">{eq.name}</TableCell>
                <TableCell className="font-mono text-right">{eq.count}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(eq.setupUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(eq.runUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(eq.repairUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(eq.waitLaborUtil, 1)}</TableCell>
                <TableCell className={`font-mono text-right font-medium ${eq.totalUtil > utilLimit ? 'text-destructive' : ''}`}>{fmtRound(eq.totalUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right text-muted-foreground">{fmtRound(eq.idle, 1)}</TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">{eq.laborGroup}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function LaborResultsTable({ labor, utilLimit }: { labor: LaborResult[]; utilLimit: number }) {
  const { sorted, sort, handleSort } = useSortableTable(labor, 'totalUtil', 'desc');
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Labor Results Table</CardTitle></CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          <TableHeader><TableRow>
            <SortHead label="Labor Group" sortKey="name"       current={sort} onSort={handleSort} align="left" />
            <SortHead label="Count"       sortKey="count"      current={sort} onSort={handleSort} />
            <SortHead label="Setup %"     sortKey="setupUtil"  current={sort} onSort={handleSort} />
            <SortHead label="Run %"       sortKey="runUtil"    current={sort} onSort={handleSort} />
            <SortHead label="Unavail %"   sortKey="unavailPct" current={sort} onSort={handleSort} />
            <SortHead label="Total %"     sortKey="totalUtil"  current={sort} onSort={handleSort} />
            <SortHead label="Idle %"      sortKey="idle"       current={sort} onSort={handleSort} />
          </TableRow></TableHeader>
          <TableBody>
            {sorted.map(l => (
              <TableRow key={l.id}>
                <TableCell className="font-mono font-medium">{l.name}</TableCell>
                <TableCell className="font-mono text-right">{l.count}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(l.setupUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(l.runUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right">{fmtRound(l.unavailPct, 1)}</TableCell>
                <TableCell className={`font-mono text-right font-medium ${l.totalUtil > utilLimit ? 'text-destructive' : ''}`}>{fmtRound(l.totalUtil, 1)}</TableCell>
                <TableCell className="font-mono text-right text-muted-foreground">{fmtRound(l.idle, 1)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

/* ─── Production Chart ─── */
const prodChartColors = {
  shipped: 'hsl(217, 91%, 60%)', usedInAssembly: 'hsl(142, 71%, 45%)',
  scrappedInAssembly: 'hsl(38, 92%, 50%)', scrapInProduction: 'hsl(0, 72%, 51%)',
};

function ProductionChart({ results, model, isMultiScenario, chartScenarios }: {
  results: CalcResults; model: any; isMultiScenario: boolean; chartScenarios: ScenarioEntry[];
}) {
  const [showTable, setShowTable] = useState(false);
  const data = useMemo(() => buildProductionData(results, model), [results, model]);
  const { sorted, sort, handleSort } = useSortableTable(data, 'total', 'desc');

  if (data.length === 0) return (
    <Card><CardContent className="py-12 text-center"><BarChart3 className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" /><p className="text-sm text-muted-foreground">Run the model to see production breakdown.</p></CardContent></Card>
  );
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div><CardTitle className="text-base">Production Chart</CardTitle><CardDescription>Breakdown of production by disposition</CardDescription></div>
          <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => setShowTable(!showTable)}>{showTable ? 'Show Chart' : 'Show as Table'}</Button>
        </div>
      </CardHeader>
      <CardContent className="relative">
        <ChartScenarioLabel />
        {showTable ? (
          <Table>
            <TableHeader><TableRow>
              <SortHead label="Product"          sortKey="name"               current={sort} onSort={handleSort} align="left" />
              <SortHead label="Shipped"          sortKey="shipped"            current={sort} onSort={handleSort} />
              <SortHead label="Used in Assy"     sortKey="usedInAssembly"     current={sort} onSort={handleSort} />
              <SortHead label="Scrapped in Assy" sortKey="scrappedInAssembly" current={sort} onSort={handleSort} />
              <SortHead label="Scrap"            sortKey="scrapInProduction"  current={sort} onSort={handleSort} />
              <SortHead label="Total"            sortKey="total"              current={sort} onSort={handleSort} />
            </TableRow></TableHeader>
            <TableBody>
              {sorted.map(d => (
                <TableRow key={d.name}>
                  <TableCell className="font-mono font-medium">{d.name}</TableCell>
                  <TableCell className="font-mono text-right">{d.shipped.toLocaleString()}</TableCell>
                  <TableCell className="font-mono text-right">{d.usedInAssembly.toLocaleString()}</TableCell>
                  <TableCell className="font-mono text-right">{d.scrappedInAssembly.toLocaleString()}</TableCell>
                  <TableCell className="font-mono text-right">{d.scrapInProduction.toLocaleString()}</TableCell>
                  <TableCell className="font-mono text-right font-medium">{d.total.toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={axisStyle} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" label={{ value: 'Units', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
              <Tooltip contentStyle={tooltipStyle} /><Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="shipped"            stackId="a" fill={prodChartColors.shipped}           name="Shipped Production" />
              <Bar dataKey="usedInAssembly"     stackId="a" fill={prodChartColors.usedInAssembly}    name="Used in Assembly" />
              <Bar dataKey="scrappedInAssembly" stackId="a" fill={prodChartColors.scrappedInAssembly} name="Scrapped in Assembly" />
              <Bar dataKey="scrapInProduction"  stackId="a" fill={prodChartColors.scrapInProduction} name="Scrap in Production" radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}