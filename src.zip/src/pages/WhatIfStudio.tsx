import { useState, useEffect, useMemo, useCallback } from 'react';
import { Checkbox } from '@/components/ui/Checkbox';
import { useParams, useNavigate } from 'react-router-dom';
import { useModelStore, type Model, displayParamNames } from '@/stores/modelStore';
import { useScenarioStore, type Scenario, type ScenarioChange, type ScenarioFamily } from '@/stores/scenarioStore';
import FamiliesTabContent from '@/components/FamiliesPanel';
import { WhatIfGeneralTab } from '@/components/whatif/WhatIfGeneralTab';
import { WhatIfLaborTab } from '@/components/whatif/WhatIfLaborTab';
import { WhatIfEquipmentTab } from '@/components/whatif/WhatIfEquipmentTab';
import { WhatIfProductsTab } from '@/components/whatif/WhatIfProductsTab';
import { WhatIfOperationsTab } from '@/components/whatif/WhatIfOperationsTab';
import { useResultsStore } from '@/stores/resultsStore';
import { useUserLevelStore, isVisible, type UserLevel } from '@/hooks/useUserLevel';
import { fullCalculate } from '@/lib/simulationApi';
import { findLaborForEquipment, resolvePureLaborEquipment } from '@/lib/pureLabor';
import { isPureLaborOperation, resolvePureLaborOperation } from '@/lib/pureLaborOperations';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/Select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Plus, Play, Save, ArrowUpCircle, ArrowLeft, ArrowRight,
  FlaskConical, Pencil, Trash2, Copy, Eye, EyeOff, Lock,
  AlertTriangle, Circle, CircleAlert, CircleCheck,
  Layers, ChevronDown, ChevronUp, ChevronRight, GripVertical, ClipboardPaste,
} from 'lucide-react';
import { getScenarioColor } from '@/lib/scenarioColors';
import { toast } from 'sonner';
import { NonNegativeNumericInput } from '@/components/NonNegativeNumericInput';

// ═══════════════════════════════════════════════════════════════════════
// Main Page
// ═══════════════════════════════════════════════════════════════════════
export default function WhatIfStudio() {
  const { modelId } = useParams<{ modelId: string }>();
  const navigate = useNavigate();
  const model = useModelStore(s => s.models.find(m => m.id === modelId));
  const { userLevel } = useUserLevelStore();

  const allScenarios = useScenarioStore(s => s.scenarios);
  const activeScenarioId = useScenarioStore(s => s.activeScenarioId);
  const displayIds = useScenarioStore(s => s.displayScenarioIds);
  const families = useScenarioStore(s => s.families).filter(f => f.modelId === modelId);
  const {
    setActiveScenario, createScenario, duplicateScenario, renameScenario,
    updateScenarioDescription, deleteScenario, toggleDisplayScenario,
    promoteToBasecase, markCalculated,
    createFamily, addToFamily, removeFromFamily, applyScenarioChange,
  } = useScenarioStore();
  const { setResults } = useResultsStore();

  const [initialized, setInitialized] = useState(false);
  const loadScenariosFromDb = useScenarioStore(s => s.loadScenariosFromDb);
  useEffect(() => {
    if (modelId && !initialized) {
      loadScenariosFromDb(modelId);
      setInitialized(true);
    }
  }, [modelId, initialized, loadScenariosFromDb]);

  const scenarios = allScenarios.filter(sc => sc.modelId === modelId);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState<string | null>(null);
  const [showPromoteModal, setShowPromoteModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showNewForm, setShowNewForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newComment, setNewComment] = useState('');
  const [familyRecordsId, setFamilyRecordsId] = useState<string | null>(null);
  const [leftTab, setLeftTab] = useState<'scenarios' | 'families'>('scenarios');

  const showFamilies = isVisible('whatif_families', userLevel);

  if (!model || !modelId) return null;

  const activeScenario = scenarios.find(s => s.id === activeScenarioId) || null;
  const selectedScenario = selectedId && selectedId !== 'basecase'
    ? scenarios.find(s => s.id === selectedId) || null
    : null;

  const handleCreate = async () => {
    if (!newName.trim()) return;
    const id = await createScenario(modelId, newName.trim(), newComment.trim());
    setActiveScenario(id);
    setSelectedId(id);
    const nm = newName.trim();
    setNewName(''); setNewComment(''); setShowNewForm(false);
    toast.success(`What-if "${nm}" created and active.`);
  };

  const handleRunScenario = async (scenario: Scenario) => {
    try {
      const basecaseResults = useResultsStore.getState().getResults('basecase');
      if (!basecaseResults) {
        const br = await fullCalculate(model, null);
        setResults('basecase', br);
      }
      const results = await fullCalculate(model, scenario);
      setResults(scenario.id, results);
      markCalculated(scenario.id);
      toast.success(`Scenario "${scenario.name}" calculated`);
    } catch (e) {
      console.error(e);
      toast.error(e instanceof Error ? e.message : 'Calculation failed');
    }
  };

  const handlePromote = () => {
    if (!activeScenarioId || !activeScenario) return;
    promoteToBasecase(activeScenarioId);
    setShowPromoteModal(false);
    setSelectedId(null);
    toast.success('Basecase updated. Run Full Calculate to see updated results.');
  };

  const handleReturnToBasecase = () => {
    if (activeScenario && activeScenario.changes.length > 0) {
      setShowReturnModal(true);
    } else {
      setActiveScenario(null);
      setSelectedId('basecase');
    }
  };

  const handleSaveAs = async (scenario: Scenario) => {
    const newId = await duplicateScenario(scenario.id);
    setActiveScenario(newId);
    setSelectedId(newId);
    toast.success(`Saved as copy of "${scenario.name}"`);
  };

  const handleLeftClick = (id: string | 'basecase') => {
    setSelectedId(id);
    setShowNewForm(false);
    setFamilyRecordsId(null);
  };

  const handleRunAndView = async (scenario: Scenario) => {
    await handleRunScenario(scenario);
    if (!displayIds.includes(scenario.id)) {
      toggleDisplayScenario(scenario.id);
    }
    if (modelId) navigate(`/models/${modelId}/run`);
  };

  const selectedScenarioValue = selectedId ?? '';

  return (
    <div style={{ display: 'flex', flexDirection: 'row', height: '100%', width: '100%', overflow: 'hidden' }}>
      {/* ═══ LEFT PANEL — 240px with tabs ═══ */}
      <div style={{ width: 240, minWidth: 240, flexShrink: 0, height: '100%', overflow: 'hidden' }} className="border-r border-border flex flex-col bg-muted/20 tablet:hidden">
        {/* Tab bar — 36px */}
        <div className="h-9 flex items-center border-b border-border shrink-0">
          <button
            onClick={() => setLeftTab('scenarios')}
            className={`flex-1 h-full text-[13px] font-medium transition-colors relative ${leftTab === 'scenarios' ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            Scenarios
            {leftTab === 'scenarios' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
          </button>
          {showFamilies && (
            <button
              onClick={() => setLeftTab('families')}
              className={`flex-1 h-full text-[13px] font-medium transition-colors relative ${leftTab === 'families' ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Families
              {leftTab === 'families' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
            </button>
          )}
        </div>

        {leftTab === 'scenarios' ? (
          <>
            <div className="flex-1 overflow-y-auto">
              {/* Basecase */}
              <button
                onClick={() => handleLeftClick('basecase')}
                className={`w-full text-left px-3 py-2.5 flex items-center gap-2 transition-colors border-b border-border/50 ${selectedId === 'basecase' ? 'bg-primary/5' : 'hover:bg-muted/50'}`}
              >
                <Lock className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                <span className="text-sm font-medium flex-1 truncate">Basecase</span>
                {!activeScenarioId && <Badge className="bg-emerald-500/15 text-emerald-600 text-[10px] border-0 shrink-0">Active</Badge>}
                <Eye className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              </button>
              {/* What-if rows */}
              {scenarios.map((sc, idx) => {
                const dotColor = getScenarioColor(idx);
                const isActive = activeScenarioId === sc.id;
                const isSelected = selectedId === sc.id;
                const isDisplayed = displayIds.includes(sc.id);
                const hasResults = useResultsStore.getState().getResults(sc.id) != null;
                const family = sc.familyId ? families.find(f => f.id === sc.familyId) : null;

                let statusBadge: React.ReactNode;
                if (isActive) {
                  statusBadge = <Badge className="bg-amber-500/15 text-amber-600 border-0 text-[10px] shrink-0 gap-0.5"><span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500" /> Active</Badge>;
                } else if (sc.status === 'needs_recalc' && hasResults) {
                  statusBadge = <Badge variant="outline" className="border-amber-400 text-amber-600 text-[10px] shrink-0 gap-0.5"><CircleAlert className="h-2.5 w-2.5" /> Stale</Badge>;
                } else if (sc.status === 'calculated') {
                  statusBadge = <Badge className="bg-emerald-500/15 text-emerald-600 border-0 text-[10px] shrink-0 gap-0.5"><CircleCheck className="h-2.5 w-2.5" /> Current</Badge>;
                } else {
                  statusBadge = <Badge variant="secondary" className="text-[10px] shrink-0 gap-0.5"><Circle className="h-2.5 w-2.5" /> Not Run</Badge>;
                }
                return (
                  <button key={sc.id} onClick={() => handleLeftClick(sc.id)}
                    className={`w-full text-left px-3 py-2.5 flex items-center gap-1.5 transition-colors border-b border-border/30 ${isSelected ? 'bg-primary/5' : 'hover:bg-muted/50'}`}
                  >
                    <span className="inline-block w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: dotColor }} />
                    <span className="text-sm font-medium flex-1 truncate">{sc.name}</span>
                    {family && showFamilies && (
                      <FamilyPill scenario={sc} family={family} families={families} modelId={modelId} />
                    )}
                    {statusBadge}
                    <button onClick={(e) => { e.stopPropagation(); toggleDisplayScenario(sc.id); }}
                      className="shrink-0 text-muted-foreground hover:text-foreground transition-colors"
                      title={isDisplayed ? 'Hide from charts' : 'Show in charts'}
                    >
                      {isDisplayed ? <Eye className="h-3.5 w-3.5" style={{ color: dotColor }} /> : <EyeOff className="h-3.5 w-3.5" />}
                    </button>
                  </button>
                );
              })}
            </div>
            <div className="p-3 border-t border-border shrink-0">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div>
                      <Button size="sm" className="w-full h-8 text-xs" onClick={() => { setShowNewForm(true); setSelectedId(null); setFamilyRecordsId(null); }} disabled={activeScenarioId !== null}>
                        <Plus className="h-3.5 w-3.5 mr-1" /> New What-if
                      </Button>
                    </div>
                  </TooltipTrigger>
                  {activeScenarioId !== null && <TooltipContent side="top"><p className="text-xs">Save or return to Basecase first.</p></TooltipContent>}
                </Tooltip>
              </TooltipProvider>
            </div>
          </>
        ) : (
          <FamiliesTabContent
            modelId={modelId}
            scenarios={scenarios}
            activeScenarioId={activeScenarioId}
            onSelectScenario={(id) => { setSelectedId(id); setLeftTab('scenarios'); }}
            onShowFamilyRecords={(fId) => { setFamilyRecordsId(fId); setSelectedId(null); setShowNewForm(false); }}
          />
        )}
      </div>

      {/* ═══ CENTRE PANEL ═══ */}
      <div style={{ flex: 1, minWidth: 0, height: '100%', overflowY: 'auto' }} className="flex flex-col">
        {/* Tablet-only scenario switcher (replaces left scenarios rail) */}
        <div className="hidden tablet:flex items-center gap-2 px-4 py-2 border-b border-border bg-background shrink-0">
          <Label htmlFor="tablet-scenario-select" className="text-xs text-muted-foreground whitespace-nowrap">
            Scenario
          </Label>
          <Select
            value={selectedScenarioValue}
            onValueChange={(value) => {
              if (value === '') {
                setSelectedId(null);
                setShowNewForm(false);
                setFamilyRecordsId(null);
                return;
              }
              handleLeftClick(value as string | 'basecase');
            }}
          >
            <SelectTrigger id="tablet-scenario-select" className="h-8 min-w-0 flex-1 text-xs">
              <SelectValue placeholder="Select scenario" />
            </SelectTrigger>
            <SelectContent className="w-[var(--radix-select-trigger-width)] max-w-[calc(100vw-2rem)]">
              <SelectItem value="basecase">Basecase</SelectItem>
              {scenarios.map((sc) => {
                const isActive = activeScenarioId === sc.id;
                const hasResults = useResultsStore.getState().getResults(sc.id) != null;
                const statusText = isActive
                  ? 'Active'
                  : sc.status === 'calculated'
                    ? 'Current'
                    : (sc.status === 'needs_recalc' && hasResults)
                      ? 'Stale'
                      : 'Not Run';
                return (
                  <SelectItem key={sc.id} value={sc.id}>
                    {`● ${sc.name} (${statusText})`}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
          <Button
            size="sm"
            className="h-8 shrink-0 text-xs"
            onClick={() => {
              setShowNewForm(true);
              setSelectedId(null);
              setFamilyRecordsId(null);
            }}
            disabled={activeScenarioId !== null}
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            New What-if
          </Button>
        </div>

        {familyRecordsId ? (
          <FamilyRecordsView
            family={families.find(f => f.id === familyRecordsId)!}
            scenarios={scenarios}
            activeScenarioId={activeScenarioId}
            model={model}
            modelId={modelId}
            userLevel={userLevel}
            onBack={() => setFamilyRecordsId(null)}
          />
        ) : showNewForm ? (
          <NewWhatIfForm newName={newName} newComment={newComment} setNewName={setNewName} setNewComment={setNewComment} onSubmit={handleCreate} onCancel={() => { setShowNewForm(false); setNewName(''); setNewComment(''); }} />
        ) : selectedId === 'basecase' ? (
          <BasecaseView model={model} />
        ) : selectedScenario ? (
          <ScenarioView
            model={model} modelId={modelId} scenario={selectedScenario}
            isActive={activeScenarioId === selectedScenario.id}
            onActivate={() => setActiveScenario(selectedScenario.id)}
            onDelete={() => setShowDeleteModal(selectedScenario.id)}
            onRename={renameScenario}
            onRunScenario={handleRunScenario}
            onSave={(s) => { handleRunScenario(s); setActiveScenario(null); }}
            onSaveAs={handleSaveAs}
            onReturnToBasecase={handleReturnToBasecase}
            onPromote={() => setShowPromoteModal(true)}
            onRunAndView={handleRunAndView}
            userLevel={userLevel}
          />
        ) : (
          <EmptyState onNew={() => setShowNewForm(true)} disabled={activeScenarioId !== null} />
        )}
      </div>

      {/* ── Modals ── */}
      {showDeleteModal && (() => {
        const sc = scenarios.find(s => s.id === showDeleteModal);
        if (!sc) return null;
        return <DeleteConfirmModal scenario={sc} onConfirm={() => { deleteScenario(showDeleteModal); if (selectedId === showDeleteModal) setSelectedId(null); setShowDeleteModal(null); toast.success(`"${sc.name}" deleted`); }} onCancel={() => setShowDeleteModal(null)} />;
      })()}

      <Dialog open={showReturnModal} onOpenChange={setShowReturnModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Return to Basecase?</DialogTitle><DialogDescription>You have unsaved changes in "{activeScenario?.name}". What would you like to do?</DialogDescription></DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="ghost" onClick={() => setShowReturnModal(false)}>Stay in What-if</Button>
            <Button variant="outline" className="border-amber-400 text-amber-700" onClick={() => { setActiveScenario(null); setShowReturnModal(false); setSelectedId('basecase'); }}>Discard Changes and Return</Button>
            <Button onClick={async () => { if (activeScenario) await handleRunScenario(activeScenario); setActiveScenario(null); setShowReturnModal(false); setSelectedId('basecase'); }}>Save and Return</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {showPromoteModal && activeScenario && <PromoteModal scenario={activeScenario} onConfirm={handlePromote} onCancel={() => setShowPromoteModal(false)} />}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Family Pill (in left panel scenario row)
// ═══════════════════════════════════════════════════════════════════════
function FamilyPill({ scenario, family, families, modelId }: {
  scenario: Scenario; family: ScenarioFamily; families: ScenarioFamily[]; modelId: string;
}) {
  const { addToFamily, removeFromFamily } = useScenarioStore();
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          onClick={(e) => { e.stopPropagation(); }}
          className="shrink-0 text-[9px] font-medium rounded-full px-1.5 py-0.5 bg-primary/10 text-primary hover:bg-primary/20 transition-colors truncate max-w-[60px]"
          title={family.name}
        >
          {family.name}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-48 p-2" align="start" onClick={(e) => e.stopPropagation()}>
        <p className="text-xs font-semibold mb-2">Move to family</p>
        <div className="space-y-1 max-h-32 overflow-y-auto">
          {families.map(f => (
            <button key={f.id} onClick={() => { addToFamily(scenario.id, f.id); setOpen(false); }}
              className={`w-full text-left text-xs px-2 py-1 rounded hover:bg-muted/50 transition-colors ${f.id === family.id ? 'bg-primary/5 font-medium' : ''}`}
            >
              {f.name}
            </button>
          ))}
        </div>
        <button onClick={() => { removeFromFamily(scenario.id); setOpen(false); }}
          className="w-full text-left text-xs px-2 py-1 rounded text-destructive hover:bg-destructive/5 transition-colors mt-1 border-t border-border pt-1.5"
        >
          Remove from family
        </button>
      </PopoverContent>
    </Popover>
  );
}

// ═══════════════════════════════════════════════════════════════════════
function FamilyRecordsView({ family, scenarios, activeScenarioId, model, modelId, userLevel, onBack }: {
  family: ScenarioFamily; scenarios: Scenario[]; activeScenarioId: string | null;
  model: Model; modelId: string; userLevel: UserLevel; onBack: () => void;
}) {
  const members = scenarios.filter(s => s.familyId === family.id);
  const [editingEnabled, setEditingEnabled] = useState(false);
  const { updateChange } = useScenarioStore();

  // Collect all unique change keys across members
  const allChangeKeys = useMemo(() => {
    const keys = new Map<string, { dataType: string; entityName: string; fieldLabel: string; field: string; entityId: string }>();
    members.forEach(m => {
      m.changes.forEach(c => {
        const key = `${c.dataType}|${c.entityId}|${c.field}`;
        if (!keys.has(key)) keys.set(key, { dataType: c.dataType, entityName: c.entityName, fieldLabel: c.fieldLabel, field: c.field, entityId: c.entityId });
      });
    });
    return Array.from(keys.entries());
  }, [members]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="h-12 px-6 flex items-center gap-3 border-b border-border shrink-0">
        <button onClick={onBack} className="text-sm text-primary hover:underline flex items-center gap-1">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to Scenario
        </button>
        <span className="text-muted-foreground">/</span>
        <Layers className="h-4 w-4 text-primary" />
        <h2 className="text-base font-semibold">{family.name}</h2>
        <Badge variant="secondary" className="text-[10px]">{members.length} members</Badge>
        <div className="flex-1" />
        {isVisible('allow_edit_whatif', userLevel) && (
          <div className="flex items-center gap-2">
            <Label className="text-xs text-muted-foreground">Enable Editing</Label>
            <Switch checked={editingEnabled} onCheckedChange={setEditingEnabled} className="scale-75" />
          </div>
        )}
      </div>

      {editingEnabled && (
        <div className="px-6 py-2 flex items-start gap-2 text-xs font-medium bg-destructive/10 text-destructive border-b border-border">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
          Editing values here permanently changes What-if overrides.
        </div>
      )}

      <div className="flex-1 overflow-auto p-6">
        {allChangeKeys.length === 0 ? (
          <div className="text-center text-sm text-muted-foreground mt-8">No changes recorded across family members.</div>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/50 text-muted-foreground">
                  <th className="text-left p-2 font-medium">Parameter</th>
                  <th className="text-left p-2 font-medium">Resource</th>
                  {members.map(m => (
                    <th key={m.id} className={`text-right p-2 font-medium ${activeScenarioId === m.id ? 'bg-amber-500/10' : ''}`}>
                      {m.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allChangeKeys.map(([key, info]) => (
                  <tr key={key} className="border-t border-border">
                    <td className="p-2 text-muted-foreground">{info.fieldLabel}</td>
                    <td className="p-2 font-medium">{info.entityName}</td>
                    {members.map(m => {
                      const change = m.changes.find(c => c.dataType === info.dataType && c.entityId === info.entityId && c.field === info.field);
                      return (
                        <td key={m.id} className={`p-2 text-right font-mono ${activeScenarioId === m.id ? 'bg-amber-500/5' : ''}`}>
                          {editingEnabled && change ? (
                            <NonNegativeNumericInput
                              allowDecimal
                              className="w-full text-right bg-transparent border border-border rounded px-1 py-0.5 font-mono text-xs h-7"
                              value={typeof change.whatIfValue === 'number' ? change.whatIfValue : Number(change.whatIfValue) || 0}
                              onChange={(v) => updateChange(m.id, change.id, v)}
                            />
                          ) : (
                            <span className={change ? 'font-semibold text-primary' : 'text-muted-foreground'}>
                              {change ? change.whatIfValue : '—'}
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Empty State
// ═══════════════════════════════════════════════════════════════════════
function EmptyState({ onNew, disabled }: { onNew: () => void; disabled: boolean }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
      <div className="rounded-full bg-primary mb-4 p-4">
        <FlaskConical className="h-10 w-10 text-foreground" />
      </div>
      <p className="text-sm mb-2 text-foreground font-medium">No What-if scenarios defined</p>
      <p className="text-sm mb-4 text-muted-foreground">Create a What-if scenario to start editing.</p>
      <Button size="lg" onClick={onNew} disabled={disabled}><Plus className="h-4 w-4 mr-2" /> New What-if</Button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// New What-if Form
// ═══════════════════════════════════════════════════════════════════════
function NewWhatIfForm({ newName, newComment, setNewName, setNewComment, onSubmit, onCancel }: {
  newName: string; newComment: string; setNewName: (v: string) => void; setNewComment: (v: string) => void; onSubmit: () => void; onCancel: () => void;
}) {
  return (
    <div className="flex-1 flex items-center justify-center p-8">
      <div className="w-full max-w-md rounded-lg border border-primary/30 bg-primary/5 p-6 space-y-4">
        <h3 className="text-base font-semibold">New What-if</h3>
        <div>
          <Label className="text-xs">Name</Label>
          <Input value={newName} onChange={e => setNewName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && newName.trim()) onSubmit(); if (e.key === 'Escape') onCancel(); }} placeholder="e.g. Reduce Setup Times" className="h-9 mt-1" autoFocus />
        </div>
        <div>
          <Label className="text-xs">Comment (optional)</Label>
          <Textarea value={newComment} onChange={e => setNewComment(e.target.value)} placeholder="Brief description" className="mt-1 text-sm min-h-[48px] resize-none" />
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" onClick={onSubmit} disabled={!newName.trim()}><Play className="h-3.5 w-3.5 mr-1" /> Start Editing</Button>
          <Button size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Basecase View — read-only tabs
// ═══════════════════════════════════════════════════════════════════════
function BasecaseView({ model }: { model: Model }) {
  const [activeTab, setActiveTab] = useState('general');
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="h-12 px-6 flex items-center gap-2 border-b border-border shrink-0">
        <Lock className="h-4 w-4 text-muted-foreground" />
        <h2 className="text-base font-semibold">Basecase</h2>
        <Badge className="bg-emerald-500/15 text-emerald-600 border-0 text-[10px] ml-2">Read-only</Badge>
      </div>
      <div className="px-6 py-1.5 text-xs text-muted-foreground border-b border-border shrink-0">
        To edit Basecase data, use the Input screens in the main navigation.
      </div>
      <div className="border-b border-border shrink-0">
        <div className="flex px-6">
          {['general','labor','equipment','products','operations'].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm font-medium transition-colors relative ${activeTab === tab ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
              {activeTab === tab && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-6">
        {activeTab === 'general' && <ReadOnlyGeneralTab model={model} />}
        {activeTab === 'labor' && <ReadOnlyLaborTab model={model} />}
        {activeTab === 'equipment' && <ReadOnlyEquipmentTab model={model} />}
        {activeTab === 'products' && <ReadOnlyProductsTab model={model} />}
        {activeTab === 'operations' && <ReadOnlyOperationsTab model={model} />}
      </div>
    </div>
  );
}

// ── Read-only helpers ──
function ReadOnlyTable({ headers, rows }: { headers: string[]; rows: (string | number)[][] }) {
  return (
    <div className="rounded-lg border border-border overflow-x-auto">
      <table className="min-w-max w-full text-xs">
        <thead><tr className="bg-muted/50 text-muted-foreground">{headers.map(h => <th key={h} className="text-left p-2 font-medium">{h}</th>)}</tr></thead>
        <tbody>{rows.map((row, i) => <tr key={i} className="border-t border-border">{row.map((cell, j) => <td key={j} className={`p-2 ${j === 0 ? 'font-medium' : 'text-muted-foreground font-mono'}`}>{cell}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

function KVGrid({ items }: { items: { label: string; value: string | number }[] }) {
  return <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-3">{items.map(i => <div key={i.label}><span className="text-xs text-muted-foreground">{i.label}</span><p className="text-sm font-mono">{i.value}</p></div>)}</div>;
}

function AdvancedToggle({ show, onToggle }: { show: boolean; onToggle: () => void }) {
  return (
    <div className="flex justify-end mb-3">
      <Button variant="outline" size="sm" onClick={onToggle} className="gap-1 text-xs">
        {show ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        {show ? 'Hide Advanced' : 'Show Advanced'}
      </Button>
    </div>
  );
}

function ReadOnlyGeneralTab({ model }: { model: Model }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const g = model.general;
  const baseItems = [
    { label: 'Model Title', value: g.model_title || '—' }, { label: 'Author', value: g.author || '—' },
    { label: 'Ops Time Unit', value: g.ops_time_unit }, { label: 'MCT Time Unit', value: g.mct_time_unit },
    { label: 'Production Period', value: g.prod_period_unit }, { label: 'Conv1', value: g.conv1 },
    { label: 'Conv2', value: g.conv2 }, { label: 'Utilisation Limit', value: `${g.util_limit}%` },
  ];
  const advancedItems = [
    { label: 'Var Equip', value: `${g.var_equip}%` }, { label: 'Var Labor', value: `${g.var_labor}%` },
    { label: 'Var Prod', value: `${g.var_prod}%` },
    { label: 'Gen1', value: g.gen1 }, { label: 'Gen2', value: g.gen2 },
    { label: 'Gen3', value: g.gen3 }, { label: 'Gen4', value: g.gen4 },
  ];
  return (
    <div>
      <AdvancedToggle show={showAdvanced} onToggle={() => setShowAdvanced(!showAdvanced)} />
      <KVGrid items={showAdvanced ? [...baseItems, ...advancedItems] : baseItems} />
    </div>
  );
}

function ReadOnlyLaborTab({ model }: { model: Model }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  if (!model.labor.length) return <p className="text-sm text-muted-foreground">No labor groups.</p>;
  const pn = displayParamNames(model);
  const baseHeaders = ['Name', 'Count', 'OT%', 'Unavail%', 'Dept'];
  const advHeaders = ['Run Fac', 'Setup Fac', 'Var Fac', 'Priority', pn.lab1_name, pn.lab2_name, pn.lab3_name, pn.lab4_name];
  const headers = showAdvanced ? [...baseHeaders, ...advHeaders] : baseHeaders;
  const rows = model.labor.map(l => {
    const base = [l.name, l.count, l.overtime_pct, l.unavail_pct, l.dept_code || '—'];
    if (showAdvanced) base.push(l.run_factor as any, l.setup_factor as any, l.var_factor as any, l.prioritize_use ? 'Yes' : 'No', l.lab1 as any, l.lab2 as any, l.lab3 as any, l.lab4 as any);
    return base;
  });
  return (
    <div>
      <AdvancedToggle show={showAdvanced} onToggle={() => setShowAdvanced(!showAdvanced)} />
      <ReadOnlyTable headers={headers} rows={rows} />
    </div>
  );
}

function ReadOnlyEquipmentTab({ model }: { model: Model }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  if (!model.equipment.length) return <p className="text-sm text-muted-foreground">No equipment.</p>;
  const pn = displayParamNames(model);
  const baseHeaders = ['Name', 'Type', 'Count', 'MTTF', 'MTTR', 'Unavail%'];
  const advHeaders = ['Dept', 'Run Fac', 'Setup Fac', 'Var Fac', pn.eq1_name, pn.eq2_name, pn.eq3_name, pn.eq4_name];
  const headers = showAdvanced ? [...baseHeaders, ...advHeaders] : baseHeaders;
  const rows = model.equipment.map(e => {
    const eff = resolvePureLaborEquipment(e, findLaborForEquipment(model.labor, e.labor_group_id));
    const base: (string | number)[] = [eff.name, e.equip_type, eff.count, eff.mttf, eff.mttr, eff.unavail_pct];
    if (showAdvanced) base.push(eff.dept_code || '—', eff.run_factor as number, eff.setup_factor as number, eff.var_factor as number, eff.eq1 as number, eff.eq2 as number, eff.eq3 as number, eff.eq4 as number);
    return base;
  });
  return (
    <div>
      <AdvancedToggle show={showAdvanced} onToggle={() => setShowAdvanced(!showAdvanced)} />
      <ReadOnlyTable headers={headers} rows={rows} />
    </div>
  );
}

function ReadOnlyProductsTab({ model, scenario, userLevel: ul }: { model: Model; scenario?: Scenario | null; userLevel?: UserLevel }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [search, setSearch] = useState('');
  if (!model.products.length) return <p className="text-sm text-muted-foreground">No products.</p>;
  const showInclude = !!scenario && !!ul && isVisible('product_inclusion', ul);
  const pn = displayParamNames(model);

  const isExcluded = (productId: string) => {
    if (!scenario) return false;
    return scenario.changes.some(c => c.dataType === 'Product' && c.entityId === productId && c.field === 'included' && String(c.whatIfValue) === 'false');
  };

  const filteredProducts = model.products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const includedCount = model.products.filter(p => !isExcluded(p.id)).length;
  const totalCount = model.products.length;

  const allChecked = model.products.every(p => !isExcluded(p.id));
  const noneChecked = model.products.every(p => isExcluded(p.id));

  const baseHeaders = ['Name', 'Demand', 'Lot Size', 'TBatch', 'Dept'];
  const advHeaders = ['Demand Fac', 'Lot Fac', 'Var Fac', 'MTS', 'Gather', pn.prod1_name, pn.prod2_name, pn.prod3_name, pn.prod4_name];
  let headers = showAdvanced ? [...baseHeaders, ...advHeaders] : [...baseHeaders];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Input
          placeholder="Search products..."
          value={search}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)}
          className="h-8 w-48 text-xs"
        />
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">{includedCount} of {totalCount} included</span>
          <AdvancedToggle show={showAdvanced} onToggle={() => setShowAdvanced(!showAdvanced)} />
        </div>
      </div>
      <div className="rounded-lg border border-border overflow-x-auto">
        <table className="min-w-max w-full text-xs">
          <thead><tr className="bg-muted/50 text-muted-foreground">
            {showInclude && (
              <th className="text-left p-2 font-medium">
                <Checkbox
                  checked={allChecked ? true : noneChecked ? false : 'indeterminate'}
                  disabled
                  className="opacity-50"
                />
              </th>
            )}
            {headers.map(h => <th key={h} className="text-left p-2 font-medium">{h}</th>)}
          </tr></thead>
          <tbody>{filteredProducts.map(p => (
            <tr key={p.id} className={`border-t border-border ${isExcluded(p.id) ? 'opacity-50' : ''}`}>
              {showInclude && (
                <td className="p-2">
                  <Checkbox checked={!isExcluded(p.id)} disabled className="opacity-50" />
                </td>
              )}
              <td className="p-2 font-medium">{p.name}</td>
              <td className="p-2 text-muted-foreground font-mono">{p.demand}</td>
              <td className="p-2 text-muted-foreground font-mono">{p.lot_size}</td>
              <td className="p-2 text-muted-foreground font-mono">{p.tbatch_size}</td>
              <td className="p-2 text-muted-foreground font-mono">{p.dept_code || '—'}</td>
              {showAdvanced && <>
                <td className="p-2 text-muted-foreground font-mono">{p.demand_factor}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.lot_factor}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.var_factor}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.make_to_stock ? 'Yes' : 'No'}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.gather_tbatches ? 'Yes' : 'No'}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.prod1}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.prod2}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.prod3}</td>
                <td className="p-2 text-muted-foreground font-mono">{p.prod4}</td>
              </>}
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

function ReadOnlyOperationsTab({ model }: { model: Model }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  if (!model.operations.length) return <p className="text-sm text-muted-foreground">No operations.</p>;
  const pm = Object.fromEntries(model.products.map(p => [p.id, p.name]));
  const em = Object.fromEntries(model.equipment.map(e => [e.id, e.name]));
  const baseHeaders = ['Product', 'Op#', 'Op Name', 'Equipment', 'Eq Setup/Lot', 'Eq Run/Pc'];
  const advHeaders = ['Eq Setup/Pc', 'Eq Run/Lot', 'Eq Setup/TB', 'Eq Run/TB', 'Lab Setup/Lot', 'Lab Run/Pc', 'Lab Setup/Pc', 'Lab Run/Lot', 'Lab Setup/TB', 'Lab Run/TB', '% Assigned'];
  const headers = showAdvanced ? [...baseHeaders, ...advHeaders] : baseHeaders;
  const rows = model.operations.map(o => {
    const eff = resolvePureLaborOperation(o, model.equipment);
    const pure = isPureLaborOperation(o, model.equipment);
    const base: (string | number)[] = [pm[o.product_id] || '—', o.op_number, o.op_name, em[o.equip_id] || '—', pure ? 'NA' : eff.equip_setup_lot, pure ? 'NA' : eff.equip_run_piece];
    if (showAdvanced) base.push(pure ? 'NA' : eff.equip_setup_piece, pure ? 'NA' : eff.equip_run_lot, pure ? 'NA' : eff.equip_setup_tbatch, pure ? 'NA' : eff.equip_run_tbatch, o.labor_setup_lot, o.labor_run_piece, o.labor_setup_piece, o.labor_run_lot, o.labor_setup_tbatch, o.labor_run_tbatch, o.pct_assigned);
    return base;
  });
  return (
    <div>
      <AdvancedToggle show={showAdvanced} onToggle={() => setShowAdvanced(!showAdvanced)} />
      <ReadOnlyTable headers={headers} rows={rows} />
    </div>
  );
}




// ═══════════════════════════════════════════════════════════════════════
// Scenario View — the core editing view
// ═══════════════════════════════════════════════════════════════════════
function ScenarioView({
  model, modelId, scenario, isActive,
  onActivate, onDelete, onRename,
  onRunScenario, onSave, onSaveAs, onReturnToBasecase, onPromote, onRunAndView, userLevel,
}: {
  model: Model; modelId: string; scenario: Scenario; isActive: boolean;
  onActivate: () => void; onDelete: () => void;
  onRename: (id: string, name: string) => void;
  onRunScenario: (s: Scenario) => void; onSave: (s: Scenario) => void; onSaveAs: (s: Scenario) => void;
  onReturnToBasecase: () => void; onPromote: () => void;
  onRunAndView: (s: Scenario) => void;
  userLevel: UserLevel;
}) {
  const [editingName, setEditingName] = useState(false);
  const [nameVal, setNameVal] = useState(scenario.name);
  const [activeTab, setActiveTab] = useState('general');
  const { applyScenarioChange, removeChange } = useScenarioStore();

  useEffect(() => { setNameVal(scenario.name); setEditingName(false); }, [scenario.id]);

  const hasResults = useResultsStore.getState().getResults(scenario.id) != null;

  const changeCounts = useMemo(() => {
    const counts: Record<string, number> = { general: 0, labor: 0, equipment: 0, products: 0, operations: 0 };
    scenario.changes.forEach(c => {
      if (c.dataType === 'General') counts.general++;
      else if (c.dataType === 'Labor') counts.labor++;
      else if (c.dataType === 'Equipment') counts.equipment++;
      else if (c.dataType === 'Product') counts.products++;
      else counts.operations++;
    });
    return counts;
  }, [scenario.changes]);

  const getWhatIfValue = useCallback((dataType: ScenarioChange['dataType'], entityId: string, field: string): string | number | null => {
    const change = scenario.changes.find(c => c.dataType === dataType && c.entityId === entityId && c.field === field);
    return change ? change.whatIfValue : null;
  }, [scenario.changes]);

  const handleWhatIfBlur = useCallback((
    dataType: ScenarioChange['dataType'], entityId: string, entityName: string,
    field: string, fieldLabel: string, value: string, basecaseValue: number | string
  ) => {
    if (value === '' || value === String(basecaseValue)) {
      const existing = scenario.changes.find(c => c.dataType === dataType && c.entityId === entityId && c.field === field);
      if (existing) removeChange(scenario.id, existing.id);
      return;
    }
    const numVal = Number(value);
    if (!isNaN(numVal)) {
      applyScenarioChange(scenario.id, dataType, entityId, entityName, field, fieldLabel, numVal);
    }
  }, [scenario.id, scenario.changes, applyScenarioChange, removeChange]);

  let statusBadge: React.ReactNode;
  if (isActive) {
    statusBadge = <Badge className="bg-amber-500/15 text-amber-600 border-0 text-[10px]">● Active</Badge>;
  } else if (scenario.status === 'calculated') {
    statusBadge = <Badge className="bg-emerald-500/15 text-emerald-600 border-0 text-[10px]">✓ Current</Badge>;
  } else if (hasResults) {
    statusBadge = <Badge variant="outline" className="border-amber-400 text-amber-600 text-[10px]">⚠ Stale</Badge>;
  } else {
    statusBadge = <Badge variant="secondary" className="text-[10px]">○ Not Run</Badge>;
  }

  const tabs = [
    { key: 'general', label: 'General' },
    { key: 'labor', label: 'Labor' },
    { key: 'equipment', label: 'Equipment' },
    { key: 'products', label: 'Products' },
    { key: 'operations', label: 'Operations' },
    { key: 'changes', label: 'Changes' },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* ── HEADER BAR — 48px ── */}
      <div className="h-12 px-6 flex items-center gap-3 border-b border-border shrink-0">
        {editingName ? (
          <Input value={nameVal} onChange={e => setNameVal(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') { onRename(scenario.id, nameVal); setEditingName(false); } if (e.key === 'Escape') setEditingName(false); }}
            onBlur={() => { onRename(scenario.id, nameVal); setEditingName(false); }}
            className="h-8 text-base font-semibold max-w-xs" autoFocus />
        ) : (
          <h2 className="text-base font-semibold cursor-pointer hover:text-primary transition-colors flex items-center gap-1.5"
            onClick={() => { setNameVal(scenario.name); setEditingName(true); }}>
            {scenario.name}
            <Pencil className="h-3 w-3 text-muted-foreground" />
          </h2>
        )}
        <div className="tablet:hidden">{statusBadge}</div>
        <div className="flex-1" />
        {isActive ? (
          <>
            <Button size="sm" className="h-8 text-xs bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => onSave(scenario)}>
              <Save className="h-3.5 w-3.5 mr-1" /> Save
            </Button>
            <Button size="sm" variant="ghost" className="text-destructive border border-destructive/30 hover:bg-destructive/5 hover:text-destructive h-8 text-xs" onClick={onDelete}>
              <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
            </Button>
          </>
        ) : (
          <>
            <Button size="sm" className="h-8 text-xs bg-emerald-600 hover:bg-emerald-700 text-white" onClick={onActivate}>
              <Pencil className="h-3.5 w-3.5 mr-1" /> Edit
            </Button>
            <Button size="sm" variant="ghost" className="text-destructive border border-destructive/30 hover:bg-destructive/5 hover:text-destructive h-8 text-xs" onClick={onDelete}>
              <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
            </Button>
          </>
        )}
      </div>

      {/* ── TAB BAR ── */}
      <div className="border-b border-border shrink-0">
        <div className="flex px-6">
          {tabs.map(tab => {
            const hasChanges = tab.key !== 'changes' && (changeCounts[tab.key] || 0) > 0;
            const isChangesTab = tab.key === 'changes';
            return (
              <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                className={`px-4 py-2.5 text-sm font-medium transition-colors relative flex items-center gap-1.5 ${activeTab === tab.key ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                {tab.label}
                {isChangesTab && scenario.changes.length > 0 && (
                  <span className="text-[10px] text-muted-foreground">({scenario.changes.length})</span>
                )}
                {hasChanges && (
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500" />
                )}
                {activeTab === tab.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── TAB CONTENT — 24px padding ── */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-6">
        {isActive ? (
          <>
            {activeTab === 'general' && <WhatIfGeneralTab model={model} scenario={scenario} />}
            {activeTab === 'labor' && <WhatIfLaborTab model={model} scenario={scenario} />}
            {activeTab === 'equipment' && <WhatIfEquipmentTab model={model} scenario={scenario} />}
            {activeTab === 'products' && <WhatIfProductsTab model={model} scenario={scenario} userLevel={userLevel} />}
            {activeTab === 'operations' && <WhatIfOperationsTab model={model} scenario={scenario} />}
            {activeTab === 'changes' && <ChangesTab scenario={scenario} isActive={isActive} userLevel={userLevel} modelId={modelId} onPromote={onPromote} />}
          </>
        ) : (
          <>
            {activeTab === 'general' && <ReadOnlyGeneralTab model={model} />}
            {activeTab === 'labor' && <ReadOnlyLaborTab model={model} />}
            {activeTab === 'equipment' && <ReadOnlyEquipmentTab model={model} />}
            {activeTab === 'products' && <ReadOnlyProductsTab model={model} scenario={scenario} userLevel={userLevel} />}
            {activeTab === 'operations' && <ReadOnlyOperationsTab model={model} />}
            {activeTab === 'changes' && <ChangesTab scenario={scenario} isActive={isActive} userLevel={userLevel} modelId={modelId} onPromote={onPromote} />}
          </>
        )}
      </div>
    </div>
  );
}



// ═══════════════════════════════════════════════════════════════════════
// Changes Tab (audit trail)
// ═══════════════════════════════════════════════════════════════════════
function ChangesTab({ scenario, isActive, userLevel, modelId, onPromote }: {
  scenario: Scenario; isActive: boolean; userLevel: UserLevel; modelId: string; onPromote?: () => void;
}) {
  const [directEdits, setDirectEdits] = useState(false);
  const { removeChange, updateChange, markNeedsRecalc } = useScenarioStore();
  const { updateLabor, updateEquipment, updateProduct, updateRouting } = useModelStore();

  const screenBadgeColor = (dt: string) => {
    if (dt === 'Labor') return 'bg-blue-100 text-blue-700';
    if (dt === 'Equipment') return 'bg-purple-100 text-purple-700';
    if (dt === 'Product') return 'bg-green-100 text-green-700';
    if (dt === 'General') return 'bg-amber-100 text-amber-700';
    return 'bg-muted text-muted-foreground';
  };

  const handleBasecaseEdit = (change: ScenarioChange, value: string) => {
    const numVal = Number(value);
    if (isNaN(numVal)) return;
    if (change.dataType === 'Labor') updateLabor(modelId, change.entityId, { [change.field]: numVal });
    else if (change.dataType === 'Equipment') updateEquipment(modelId, change.entityId, { [change.field]: numVal });
    else if (change.dataType === 'Product') updateProduct(modelId, change.entityId, { [change.field]: numVal });
    else if (change.dataType === 'Routing') updateRouting(modelId, change.entityId, { [change.field]: numVal });
  };

  const handleWhatIfEdit = (changeId: string, value: string) => {
    const numVal = Number(value);
    if (!isNaN(numVal)) {
      updateChange(scenario.id, changeId, numVal);
      markNeedsRecalc(scenario.id);
    }
  };

  if (scenario.changes.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        {isActive ? 'No changes yet. Edit values in the tabs above to build this What-if.' : 'No changes recorded.'}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {isActive && isVisible('allow_edit_whatif', userLevel) && (
        <div className="flex items-center gap-2">
          <Label className="text-xs text-muted-foreground">Allow Direct Edits</Label>
          <Switch checked={directEdits} onCheckedChange={setDirectEdits} className="scale-75" />
        </div>
      )}

      {directEdits && (
        <div className="flex items-start gap-2 rounded-md px-3 py-2 text-xs font-medium bg-destructive/10 text-destructive">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
          Editing Basecase Value here permanently changes your model and cannot be undone.
        </div>
      )}

      <div className="rounded-lg border border-border overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-muted/50 text-muted-foreground">
              <th className="text-left p-2 font-medium w-8">#</th>
              <th className="text-left p-2 font-medium">Domain</th>
              <th className="text-left p-2 font-medium">Resource</th>
              <th className="text-left p-2 font-medium">Parameter</th>
              <th className={`text-right p-2 font-medium ${directEdits ? 'bg-red-50' : ''}`}>Basecase Value</th>
              <th className="text-right p-2 font-medium">What-if Value</th>
              <th className="text-right p-2 font-medium">Change</th>
              {isActive && <th className="p-2 w-8"></th>}
            </tr>
          </thead>
          <tbody>
            {scenario.changes.map((c, idx) => {
              const isIncluded = c.field === 'included' && c.dataType === 'Product';
              const displayBase = isIncluded ? 'Yes' : c.basecaseValue;
              const displayWi = isIncluded ? 'No' : c.whatIfValue;
              const base = Number(c.basecaseValue);
              const wi = Number(c.whatIfValue);
              const delta = (!isNaN(base) && !isNaN(wi) && !isIncluded) ? wi - base : null;
              return (
                <tr key={c.id} className="border-t border-border hover:bg-amber-500/5">
                  <td className="p-2 text-muted-foreground">{idx + 1}</td>
                  <td className="p-2">
                    <span className={`inline-block text-[10px] font-medium rounded px-1.5 py-0.5 ${screenBadgeColor(c.dataType)}`}>{c.dataType}</span>
                  </td>
                  <td className="p-2 font-medium">{c.entityName}</td>
                  <td className="p-2 text-muted-foreground">{c.fieldLabel}</td>
                  <td className={`p-2 text-right font-mono ${directEdits && !isIncluded ? 'bg-red-50/50' : ''}`}>
                    {directEdits && !isIncluded ? (
                      <NonNegativeNumericInput
                        allowDecimal
                        className="w-full text-right bg-transparent border border-destructive/30 rounded px-1 py-0.5 font-mono text-xs h-7"
                        value={typeof c.basecaseValue === 'number' ? c.basecaseValue : Number(c.basecaseValue) || 0}
                        onChange={(v) => handleBasecaseEdit(c, String(v))}
                      />
                    ) : (
                      <span className="text-muted-foreground">{displayBase}</span>
                    )}
                  </td>
                  <td className="p-2 text-right font-mono">
                    {directEdits && !isIncluded ? (
                      <NonNegativeNumericInput
                        allowDecimal
                        className="w-full text-right bg-transparent border border-border rounded px-1 py-0.5 font-mono text-xs h-7"
                        value={typeof c.whatIfValue === 'number' ? c.whatIfValue : Number(c.whatIfValue) || 0}
                        onChange={(v) => handleWhatIfEdit(c.id, String(v))}
                      />
                    ) : (
                      <span className="font-semibold text-primary">{displayWi}</span>
                    )}
                  </td>
                  <td className="p-2 text-right font-mono">
                    {delta !== null && delta !== 0 ? (
                      <span className={delta >= 0 ? 'text-emerald-600' : 'text-red-500'}>
                        {delta >= 0 ? '+' : ''}{delta % 1 === 0 ? delta : delta.toFixed(2)}
                      </span>
                    ) : '—'}
                  </td>
                  {isActive && (
                    <td className="p-2">
                      <button onClick={() => removeChange(scenario.id, c.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Lifecycle section — Promote to Basecase */}
      {isActive && onPromote && (
        <div className="mt-6 pt-4 border-t border-border">
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Lifecycle</h4>
          <Button size="sm" variant="outline" className="h-8 text-xs border-destructive/40 text-destructive hover:bg-destructive/5" onClick={onPromote}>
            <AlertTriangle className="h-3.5 w-3.5 mr-1" /> Promote to Basecase
          </Button>
          <p className="text-[11px] text-muted-foreground mt-2">
            Applies all What-if changes permanently to the Basecase. This cannot be undone.
          </p>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Delete Confirmation Modal
// ═══════════════════════════════════════════════════════════════════════
function DeleteConfirmModal({ scenario, onConfirm, onCancel }: {
  scenario: Scenario; onConfirm: () => void; onCancel: () => void;
}) {
  const [typedName, setTypedName] = useState('');
  const needsTyping = scenario.changes.length > 5;
  const canDelete = needsTyping ? typedName === scenario.name : true;
  return (
    <Dialog open onOpenChange={(open) => { if (!open) onCancel(); }}>
      <DialogContent>
        <DialogHeader><DialogTitle>Delete "{scenario.name}"?</DialogTitle><DialogDescription>This will permanently remove this scenario and all its {scenario.changes.length} change{scenario.changes.length !== 1 ? 's' : ''}. This cannot be undone.</DialogDescription></DialogHeader>
        {needsTyping && <div className="space-y-2"><Label className="text-xs">Type the What-if name to confirm:</Label><Input value={typedName} onChange={e => setTypedName(e.target.value)} placeholder={scenario.name} className="h-8 font-mono" autoFocus /></div>}
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button variant="outline" className="border-destructive text-destructive hover:bg-destructive/5" onClick={onConfirm} disabled={!canDelete}>Delete Permanently</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// Promote to Basecase Modal
// ═══════════════════════════════════════════════════════════════════════
function PromoteModal({ scenario, onConfirm, onCancel }: {
  scenario: Scenario; onConfirm: () => void; onCancel: () => void;
}) {
  const [typedName, setTypedName] = useState('');
  const canPromote = typedName === scenario.name;
  const screenBadgeColor = (dt: string) => {
    if (dt === 'Labor') return 'bg-blue-100 text-blue-700';
    if (dt === 'Equipment') return 'bg-purple-100 text-purple-700';
    if (dt === 'Product') return 'bg-green-100 text-green-700';
    if (dt === 'General') return 'bg-amber-100 text-amber-700';
    return 'bg-muted text-muted-foreground';
  };
  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-8 space-y-6">
        <div className="flex flex-col items-center text-center gap-3">
          <div className="h-16 w-16 rounded-full flex items-center justify-center bg-destructive/10">
            <AlertTriangle className="h-8 w-8 text-destructive" />
          </div>
          <h2 className="text-xl font-bold">Promote "{scenario.name}" to Basecase?</h2>
        </div>
        <div>
          <h3 className="text-sm font-semibold mb-2">The following changes will become permanent:</h3>
          {scenario.changes.length === 0 ? <p className="text-sm text-muted-foreground">No changes recorded.</p> : (
            <div className="rounded-lg border border-border overflow-hidden max-h-64 overflow-y-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-muted/50 text-muted-foreground text-xs sticky top-0">
                  <th className="text-left p-2 font-medium w-8">#</th><th className="text-left p-2 font-medium">Parameter</th>
                  <th className="text-left p-2 font-medium">Screen</th><th className="text-right p-2 font-medium">Basecase</th><th className="text-right p-2 font-medium">What-if</th>
                </tr></thead>
                <tbody>{scenario.changes.map((c, idx) => (
                  <tr key={c.id} className="border-t border-border text-xs">
                    <td className="p-2 text-muted-foreground">{idx + 1}</td>
                    <td className="p-2"><span className="font-medium">{c.entityName}</span> · {c.fieldLabel}</td>
                    <td className="p-2"><span className={`inline-block text-[10px] font-medium rounded px-1.5 py-0.5 ${screenBadgeColor(c.dataType)}`}>{c.dataType}</span></td>
                    <td className="p-2 text-right font-mono text-muted-foreground">{c.basecaseValue}</td>
                    <td className="p-2 text-right font-mono font-semibold text-primary">{c.whatIfValue}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
        <p className="text-sm font-bold text-destructive">This is permanent. Your Basecase data will be overwritten. This cannot be undone.</p>
        <div><Label className="text-xs">Type the What-if name to confirm:</Label><Input value={typedName} onChange={e => setTypedName(e.target.value)} placeholder={scenario.name} className="h-8 mt-1 font-mono max-w-sm" autoFocus /></div>
        <div className="flex items-center justify-end gap-3 pt-2">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button variant="outline" onClick={onConfirm} disabled={!canPromote} className="border-destructive text-destructive hover:bg-destructive/5">
            <ArrowUpCircle className="h-4 w-4 mr-2" /> Promote to Basecase
          </Button>
        </div>
      </div>
    </div>
  );
}